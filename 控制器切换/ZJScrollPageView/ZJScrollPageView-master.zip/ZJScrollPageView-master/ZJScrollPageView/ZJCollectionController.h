//
//  ZJCollectionController.h
//  ZJScrollPageView
//
//  Created by ZeroJ on 16/7/7.
//  Copyright © 2016年 ZeroJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZJPageController.h"

@interface ZJCollectionController : ZJPageController

@end
