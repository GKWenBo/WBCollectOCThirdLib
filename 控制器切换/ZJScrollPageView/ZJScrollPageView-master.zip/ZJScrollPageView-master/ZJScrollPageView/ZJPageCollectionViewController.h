//
//  ZJPageCollectionViewController.h
//  ZJScrollPageView
//
//  Created by ZeroJ on 16/8/31.
//  Copyright © 2016年 ZeroJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZJPageViewController.h"
#import "ZJScrollPageViewDelegate.h"

@interface ZJPageCollectionViewController : ZJPageViewController<ZJScrollPageViewChildVcDelegate>

@end
