//
//  TextViewController.h
//  ZJScrollPageView
//
//  Created by jasnig on 16/5/7.
//  Copyright © 2016年 ZeroJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZJScrollPageViewDelegate.h"

@interface ZJTestViewController : UIViewController <ZJScrollPageViewChildVcDelegate>
@end
