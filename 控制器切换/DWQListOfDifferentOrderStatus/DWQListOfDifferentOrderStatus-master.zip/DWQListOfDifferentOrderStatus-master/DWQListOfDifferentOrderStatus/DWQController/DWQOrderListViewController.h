//
//  DWQOrderListViewController.h
//  DWQListOfDifferentOrderStatus
//
//  Created by 杜文全 on 15/11/1.
//  Copyright © 2015年 com.iOSDeveloper.duwenquan. All rights reserved.
//
#define DWQMainScreenWidth [UIScreen mainScreen].bounds.size.width
#define DWQMainScreenHeight [UIScreen mainScreen].bounds.size.height
#define DWQMainScreenBounds [UIScreen mainScreen].bounds
#define Button_Origin_Tag 78
#import <UIKit/UIKit.h>

@interface DWQOrderListViewController : UIViewController
@property (nonatomic,assign) NSInteger index;
@end
