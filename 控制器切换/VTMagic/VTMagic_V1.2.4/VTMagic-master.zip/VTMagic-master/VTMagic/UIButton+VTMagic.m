//
//  UIButton+VTMagic.m
//  Pods
//
//  Created by tianzhuo on 8/18/16.
//
//

#import "UIButton+VTMagic.h"

@implementation UIButton (VTMagic)

@end
