//
//  UIButton+VTMagic.h
//  Pods
//
//  Created by tianzhuo on 8/18/16.
//
//

#import <UIKit/UIKit.h>
#import "VTMagicProtocol.h"

@interface UIButton (VTMagic)<VTMagicReuseProtocol>

@end
