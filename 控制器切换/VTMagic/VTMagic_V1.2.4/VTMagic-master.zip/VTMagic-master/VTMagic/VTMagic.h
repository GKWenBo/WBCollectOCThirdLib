//
//  VTMagic.h
//  VTMagic
//
//  Created by tianzhuo on 15/10/17.
//  Copyright © 2015年 tianzhuo. All rights reserved.
//

#ifndef VTMagic_h
#define VTMagic_h

#import "VTMagicController.h"

#endif /* VTMagic_h */
