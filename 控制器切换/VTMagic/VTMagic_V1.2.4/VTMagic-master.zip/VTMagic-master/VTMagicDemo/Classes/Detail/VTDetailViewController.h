//
//  VTDetailViewController.h
//  VTMagic
//
//  Created by tianzhuo on 7/7/16.
//  Copyright © 2016 tianzhuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VTDetailViewController : UIViewController

@end
