//
//  VTRelateViewController.h
//  VTMagic
//
//  Created by tianzhuo on 7/7/16.
//  Copyright © 2016 tianzhuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VTRelateViewController : UITableViewController

/**
 *  菜单信息
 */
@property (nonatomic, strong) MenuInfo *menuInfo;

@end
