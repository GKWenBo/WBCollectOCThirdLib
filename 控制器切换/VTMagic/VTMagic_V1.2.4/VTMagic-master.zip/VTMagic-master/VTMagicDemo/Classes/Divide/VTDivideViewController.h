//
//  VTDivideViewController.h
//  VTMagic
//
//  Created by tianzhuo on 6/1/16.
//  Copyright © 2016 tianzhuo. All rights reserved.
//

#import <VTMagic/VTMagic.h>

@interface VTDivideViewController : VTMagicController

@end
