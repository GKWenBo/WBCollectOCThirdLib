//
//  VTCenterViewController.h
//  VTMagic
//
//  Created by tianzhuo on 6/1/16.
//  Copyright © 2016 tianzhuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VTCenterViewController : UIViewController

@end
