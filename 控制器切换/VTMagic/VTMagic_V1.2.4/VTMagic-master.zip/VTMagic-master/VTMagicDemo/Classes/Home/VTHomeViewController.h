//
//  ViewController.h
//  VTMagicView
//
//  Created by tianzhuo on 14-11-11.
//  Copyright (c) 2014年 tianzhuo. All rights reserved.
//

#import <VTMagic/VTMagic.h>

@interface VTHomeViewController : VTMagicController


@end

