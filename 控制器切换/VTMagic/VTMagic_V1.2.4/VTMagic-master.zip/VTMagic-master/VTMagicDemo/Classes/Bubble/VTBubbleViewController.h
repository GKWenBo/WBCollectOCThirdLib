//
//  VTBubbleViewController.h
//  VTMagic
//
//  Created by tianzhuo on 6/4/16.
//  Copyright © 2016 tianzhuo. All rights reserved.
//

#import <VTMagic/VTMagic.h>

@interface VTBubbleViewController : VTMagicController

@end
