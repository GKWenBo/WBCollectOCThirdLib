//
//  FirstViewViewController.h
//  HYNavigation
//
//  Created by runlhy on 16/9/27.
//  Copyright © 2016年 Pengcent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewViewController : UIViewController

@property (nonatomic, strong) id parameter;

@end
