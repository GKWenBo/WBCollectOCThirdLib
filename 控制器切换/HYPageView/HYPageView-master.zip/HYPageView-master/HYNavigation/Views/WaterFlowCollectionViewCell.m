//
//  WaterFlowCollectionViewCell.m
//  CollectionPictures
//
//  Created by runlhy on 16/7/2.
//  Copyright © 2016年 runlhy. All rights reserved.
//

#import "WaterFlowCollectionViewCell.h"

@implementation WaterFlowCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
