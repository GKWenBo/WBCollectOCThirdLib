//
//  WaterFlowCollectionViewCell.h
//  CollectionPictures
//
//  Created by runlhy on 16/7/2.
//  Copyright © 2016年 runlhy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WaterFlowCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@end
