# HYPageView
## 类似优酷，网易云音乐导航条，代码足够简单，使用足够简单。


![HYPageView05.gif](http://upload-images.jianshu.io/upload_images/1155795-5a42faa4b377b337.gif?imageMogr2/auto-orient/strip)



![HYPageView08.gif](http://upload-images.jianshu.io/upload_images/1155795-e905d58548e59b82.gif?imageMogr2/auto-orient/strip)



![HYPageView06.gif](http://upload-images.jianshu.io/upload_images/1155795-217300c36772e630.gif?imageMogr2/auto-orient/strip)



![HYPageView03.gif](http://upload-images.jianshu.io/upload_images/1155795-359466ab92244108.gif?imageMogr2/auto-orient/strip)


