//
//  ChildOneViewController.h
//  CAPSPageMenuDemo
//
//  Created by WMB on 2017/2/21.
//  Copyright © 2017年 文波. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChildOneViewController : UIViewController

@end
