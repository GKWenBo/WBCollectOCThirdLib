//
//  ViewController.m
//  CAPSPageMenuDemo
//
//  Created by WMB on 2017/2/21.
//  Copyright © 2017年 文波. All rights reserved.
//

#import "ViewController.h"

#import "ChildOneViewController.h"

#import "ChildTwoViewController.h"

#import "ChildThreeViewController.h"

#import "CAPSPageMenu.h"


/**
 *  屏幕宽高
 */
#define SCREEN_WIDTH   [UIScreen mainScreen].bounds.size.width
#define SCREENH_HEIGHT [UIScreen mainScreen].bounds.size.height
#define SCREEN_BOUNDS [UIScreen mainScreen].bounds
#define kTABBAR_HEIGHT 49.0f
#define kNAVIGATIONBAR_HEIGHT 44.0f
#define kSTATUSBAR_HEIGHT 20.0f
@interface ViewController () <UIScrollViewDelegate,CAPSPageMenuDelegate>

//控制器数组
@property (nonatomic,strong) NSArray * childControllers;
/**  设置样式  */
@property (nonatomic,strong) NSDictionary * parameters;
/**  控制器名字  */
@property (nonatomic,strong) NSArray * titles;


@property (nonatomic,strong) CAPSPageMenu * pageMenu;



@end

@implementation ViewController

#pragma mark -- LifeCycle
#pragma mark
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self addChildViewController:self.pageMenu];
    [self.view addSubview:self.pageMenu.view];
    
}

#pragma mark -- CAPSPageMenuDelegate
#pragma mark
- (void)willMoveToPage:(UIViewController *)controller index:(NSInteger)index {
    NSLog(@"将要%ld",index);
}
- (void)didMoveToPage:(UIViewController *)controller index:(NSInteger)index {
    NSLog(@"已经%ld",index);
}
#pragma mark -- getter and setter
#pragma mark
- (NSArray *)titles {
    if (!_titles) {
        _titles = @[@"音乐",
                    @"电影",
                    @"歌剧"];
    }
    return _titles;
}
- (NSArray *)childControllers {
    if (!_childControllers) {
        _childControllers = @[[ChildOneViewController new],
                              [ChildTwoViewController new],
                              [ChildThreeViewController new]];
        for (NSInteger index = 0; index < _childControllers.count; index ++) {
            UIViewController * vc = _childControllers[index];
            vc.title = self.titles[index];
        }
    }
    return _childControllers;
}
- (NSDictionary *)parameters {
    if (!_parameters) {
        _parameters = @{
                        //滚动图背景色
                        CAPSPageMenuOptionScrollMenuBackgroundColor:[UIColor whiteColor],
                        CAPSPageMenuOptionViewBackgroundColor:[UIColor clearColor],
                        //选中item颜色
                        CAPSPageMenuOptionSelectedMenuItemLabelColor:[UIColor orangeColor],
                        //未选中item颜色
                        CAPSPageMenuOptionUnselectedMenuItemLabelColor:[UIColor blackColor],
                        //滑动条颜色
                        CAPSPageMenuOptionSelectionIndicatorColor:[UIColor orangeColor],
                        //最下面横线颜色
                        CAPSPageMenuOptionBottomMenuHairlineColor:[UIColor lightGrayColor],
                        //指示器高度
                        CAPSPageMenuOptionSelectionIndicatorHeight:@(1),
                        //item字体大小
                        CAPSPageMenuOptionMenuItemFont:[UIFont systemFontOfSize:14],
                        //item导航条高度
                        CAPSPageMenuOptionMenuHeight:@(44),
                        //item宽度
                        CAPSPageMenuOptionMenuItemWidth:@(SCREEN_WIDTH / 3),
                        CAPSPageMenuOptionCenterMenuItems:@(YES),
                        CAPSPageMenuOptionMenuItemSeparatorWidth:@(SCREEN_WIDTH / 3),
                        CAPSPageMenuOptionUseMenuLikeSegmentedControl:@(YES),
                        CAPSPageMenuOptionMenuMargin:@(0.001)
                        };
    }
    return _parameters;
}
- (CAPSPageMenu *)pageMenu {
    if (!_pageMenu) {
        _pageMenu = [[CAPSPageMenu alloc]initWithViewControllers:self.childControllers frame:CGRectMake(0, 64, SCREEN_WIDTH, SCREENH_HEIGHT - 64) options:self.parameters];
        _pageMenu.delegate = self;
    }
    return _pageMenu;
}






@end
