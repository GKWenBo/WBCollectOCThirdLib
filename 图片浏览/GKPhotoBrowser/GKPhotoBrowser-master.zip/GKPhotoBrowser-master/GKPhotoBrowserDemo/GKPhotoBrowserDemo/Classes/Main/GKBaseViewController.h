//
//  GKBaseViewController.h
//  GKPhotoBrowser
//
//  Created by QuintGao on 2017/11/7.
//  Copyright © 2017年 QuintGao. All rights reserved.
//

#import <GKNavigationBarViewController/GKNavigationBarViewController.h>

@interface GKBaseViewController : GKNavigationBarViewController

@end
