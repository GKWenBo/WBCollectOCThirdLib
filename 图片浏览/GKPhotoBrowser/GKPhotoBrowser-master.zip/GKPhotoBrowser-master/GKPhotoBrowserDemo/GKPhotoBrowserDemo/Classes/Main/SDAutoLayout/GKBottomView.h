//
//  GKSDBottomView.h
//  GKPhotoBrowserDemo
//
//  Created by gaokun on 2018/8/13.
//  Copyright © 2018年 QuintGao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SDAutoLayout/SDAutoLayout.h>

@interface GKBottomView : UIView

@property (nonatomic, copy) NSString *text;

@end
