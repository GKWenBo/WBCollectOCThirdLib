//
//  GKToutiaoDetailViewController.h
//  GKPhotoBrowser
//
//  Created by QuintGao on 2017/11/11.
//  Copyright © 2017年 QuintGao. All rights reserved.
//

#import "GKBaseViewController.h"

@interface GKJianshuViewController : GKBaseViewController

@property (nonatomic, copy) NSString *url;

@end
