//
//  GKOriginImageViewController.h
//  GKPhotoBrowserDemo
//
//  Created by gaokun on 2019/4/25.
//  Copyright © 2019 QuintGao. All rights reserved.
//

#import "GKBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GKOriginImageViewController : GKBaseViewController

@end

NS_ASSUME_NONNULL_END
