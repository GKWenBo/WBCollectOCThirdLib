//
//  GKGIFViewController.h
//  GKPhotoBrowserDemo
//
//  Created by gaokun on 2018/6/13.
//  Copyright © 2018年 QuintGao. All rights reserved.
//

#import "GKBaseViewController.h"

@interface GKGIFViewController : GKBaseViewController

@end
