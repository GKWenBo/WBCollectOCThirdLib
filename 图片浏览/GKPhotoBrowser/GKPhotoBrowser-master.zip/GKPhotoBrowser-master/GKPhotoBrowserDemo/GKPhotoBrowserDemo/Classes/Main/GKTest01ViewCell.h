//
//  GKTest01ViewCell.h
//  GKPhotoBrowser
//
//  Created by QuintGao on 2017/10/25.
//  Copyright © 2017年 QuintGao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GKTest01ViewCell : UITableViewCell

@property (nonatomic, strong) UIImageView *imgView;

@end
