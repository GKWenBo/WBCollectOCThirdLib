//
//  GKToutiaoViewController.h
//  GKPhotoBrowser
//
//  Created by QuintGao on 2017/11/9.
//  Copyright © 2017年 QuintGao. All rights reserved.
//

#import "GKBaseViewController.h"

@interface GKToutiaoViewController : GKBaseViewController

@end
