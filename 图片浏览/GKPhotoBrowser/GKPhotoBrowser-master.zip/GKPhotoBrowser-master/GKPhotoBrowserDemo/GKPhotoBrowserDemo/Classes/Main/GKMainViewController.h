//
//  GKMainViewController.h
//  GKPhotoBrowser
//
//  Created by QuintGao on 2017/10/25.
//  Copyright © 2017年 QuintGao. All rights reserved.
//

#import <GKNavigationBarViewController/GKNavigationBarViewController.h>

@interface GKMainViewController : GKNavigationBarViewController

@end
