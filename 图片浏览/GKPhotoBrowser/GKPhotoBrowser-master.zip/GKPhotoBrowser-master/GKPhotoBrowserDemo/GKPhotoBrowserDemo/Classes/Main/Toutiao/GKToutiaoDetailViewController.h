//
//  GKToutiaoDetailViewController.h
//  GKPhotoBrowser
//
//  Created by QuintGao on 2017/11/13.
//  Copyright © 2017年 QuintGao. All rights reserved.
//

#import "GKBaseViewController.h"
#import "GKToutiaoModel.h"

@interface GKToutiaoDetailViewController : GKBaseViewController

@property (nonatomic, strong) GKToutiaoModel *model;

@end
