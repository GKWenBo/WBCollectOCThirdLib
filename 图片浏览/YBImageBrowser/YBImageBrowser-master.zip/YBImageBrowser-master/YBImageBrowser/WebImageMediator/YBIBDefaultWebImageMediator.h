//
//  YBIBDefaultWebImageMediator.h
//  YBImageBrowserDemo
//
//  Created by 波儿菜 on 2019/8/27.
//  Copyright © 2019 杨波. All rights reserved.
//

#import "YBIBWebImageMediator.h"

NS_ASSUME_NONNULL_BEGIN

@interface YBIBDefaultWebImageMediator : NSObject <YBIBWebImageMediator>

@end

NS_ASSUME_NONNULL_END
