//
//  TestToolViewHandler.h
//  YBImageBrowserDemo
//
//  Created by 波儿菜 on 2019/7/16.
//  Copyright © 2019 杨波. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YBIBToolViewHandler.h"

NS_ASSUME_NONNULL_BEGIN

@interface TestToolViewHandler : NSObject <YBIBToolViewHandler>

@end

NS_ASSUME_NONNULL_END
