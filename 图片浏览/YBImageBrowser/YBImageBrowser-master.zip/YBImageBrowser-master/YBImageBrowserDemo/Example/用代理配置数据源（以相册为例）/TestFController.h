//
//  TestFController.h
//  YBImageBrowserDemo
//
//  Created by 波儿菜 on 2019/8/4.
//  Copyright © 2019 杨波. All rights reserved.
//

#import "BaseListController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TestFController : BaseListController

@end

NS_ASSUME_NONNULL_END
