//
//  MainNavigationController.h
//  YBImageBrowserDemo
//
//  Created by 波儿菜 on 2018/9/17.
//  Copyright © 2018年 波儿菜. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainNavigationController : UINavigationController

@end
