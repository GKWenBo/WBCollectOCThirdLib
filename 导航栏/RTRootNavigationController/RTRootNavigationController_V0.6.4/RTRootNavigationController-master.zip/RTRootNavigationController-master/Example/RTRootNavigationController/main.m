//
//  main.m
//  RTRootNavigationController
//
//  Created by rickytan on 06/08/2016.
//  Copyright (c) 2016 rickytan. All rights reserved.
//

@import UIKit;
#import "RTAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RTAppDelegate class]));
    }
}
