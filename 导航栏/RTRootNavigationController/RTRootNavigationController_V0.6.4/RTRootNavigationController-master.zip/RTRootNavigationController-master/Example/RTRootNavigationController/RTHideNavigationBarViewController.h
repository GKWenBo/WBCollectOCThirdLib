//
//  RTHideNavigationBarViewController.h
//  RTRootNavigationController
//
//  Created by ricky on 16/6/9.
//  Copyright © 2016年 rickytan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RTHideNavigationBarViewController : UIViewController

@end
