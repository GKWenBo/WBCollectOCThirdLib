//
//  RTStatusHiddenViewController.h
//  RTRootNavigationController
//
//  Created by Ricky on 2017/8/3.
//  Copyright © 2017年 rickytan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RTStatusHiddenViewController : UIViewController

@end
