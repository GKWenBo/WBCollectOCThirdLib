//
//  YPNavigationController+Configure.h
//  YPNavigationBarTransition-Example
//
//  Created by Guoyin Lee on 2018/4/25.
//  Copyright © 2018 yiplee. All rights reserved.
//

#import <YPNavigationBarTransition/YPNavigationBarTransition.h>

@interface YPNavigationController (Configure)<YPNavigationBarConfigureStyle>

@end
