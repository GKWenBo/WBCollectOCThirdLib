//
//  YPGradientDemoViewController.h
//  YPNavigationBarTransition-Example
//
//  Created by Li Guoyin on 2017/12/30.
//  Copyright © 2017年 yiplee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <YPNavigationBarTransition/YPNavigationBarTransition.h>

@interface YPGradientDemoViewController : UIViewController<YPNavigationBarConfigureStyle>

@end
