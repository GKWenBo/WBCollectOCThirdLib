//
//  YPDemoViewController.h
//  YPNavigationBarTransition-Example
//
//  Created by Guoyin Lee on 25/12/2017.
//  Copyright © 2017 yiplee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YPDemoViewController : UIViewController

@end
