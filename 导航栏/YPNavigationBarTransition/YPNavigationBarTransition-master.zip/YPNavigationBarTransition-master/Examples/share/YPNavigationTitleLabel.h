//
//  YPNavigationTitleLabel.h
//  YPNavigationBarTransition-Example
//
//  Created by Li Guoyin on 2017/12/26.
//  Copyright © 2017年 yiplee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YPNavigationTitleLabel : UILabel

@end
