//
//  TranslucentBlackBarStyleObject.h
//  YPNavigationBarTransitionTests
//
//  Created by Guoyin Lee on 27/12/2017.
//  Copyright © 2017 yiplee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <YPNavigationBarTransition/YPNavigationBarTransition.h>

@interface TranslucentBlackBarStyleObject : NSObject<YPNavigationBarConfigureStyle>

@end
