//
//  ViewController.swift
//  Example
//
//  Created by Suyeol Jeon on 02/04/2017.
//  Copyright © 2017 Suyeol Jeon. All rights reserved.
//

import UIKit
import UINavigationItem_Margin

class ViewController: UIViewController {

  override func viewDidLoad() {
    super.viewDidLoad()
    self.navigationItem.leftMargin = 0
    self.navigationItem.rightMargin = 0
  }

}

