//
//  NSString+StringHook.h
//  JJException
//
//  Created by Jezz on 2018/9/18.
//  Copyright © 2018年 Jezz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (StringHook)

+ (void)jj_swizzleNSString;

@end
