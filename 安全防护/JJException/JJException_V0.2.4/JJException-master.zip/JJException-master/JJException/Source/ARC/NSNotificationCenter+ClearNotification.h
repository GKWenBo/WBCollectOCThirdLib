//
//  NSNotificationCenter+ClearNotification.h
//  JJException
//
//  Created by Jezz on 2018/9/6.
//  Copyright © 2018年 Jezz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSNotificationCenter (ClearNotification)

+ (void)jj_swizzleNSNotificationCenter;

@end
