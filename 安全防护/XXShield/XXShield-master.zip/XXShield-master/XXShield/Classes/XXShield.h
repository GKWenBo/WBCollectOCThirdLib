//
//  XXShield.h
//  Pods
//
//  Created by nero on 2017/10/31.
//

#import <Foundation/Foundation.h>

//! Project version number for Expecta.
FOUNDATION_EXPORT double XXShieldVersionNumber;

//! Project version string for Expecta.
FOUNDATION_EXPORT const unsigned char XXShieldVersionString[];

#import <XXShield/XXShieldSDK.h>
