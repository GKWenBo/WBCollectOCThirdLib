//
//  main.m
//  XXShield
//
//  Created by XXShield on 07/10/2017.
//  Copyright (c) 2017 XXShield. All rights reserved.
//

@import UIKit;
#import "XXAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([XXAppDelegate class]));
    }
}
