//
//  XXAppDelegate.h
//  XXShield
//
//  Created by XXShield on 07/10/2017.
//  Copyright (c) 2017 XXShield. All rights reserved.
//

@import UIKit;

@interface XXAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
