//
//  Student.m
//  ios_black_magic_homework
//
//  Created by nero on 2017/2/20.
//  Copyright © 2017年 nero. All rights reserved.
//

#import "Student.h"

@implementation Student

- (void)dealloc {
    NSLog(@"student dealloced");
}

@end
