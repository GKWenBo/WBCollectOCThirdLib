//
//  XXViewController.h
//  XXShield
//
//  Created by XXShield on 07/10/2017.
//  Copyright (c) 2017 XXShield. All rights reserved.
//

@import UIKit;

@interface XXViewController : UIViewController

@end
