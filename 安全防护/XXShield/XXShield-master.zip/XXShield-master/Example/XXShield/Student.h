//
//  Student.h
//  ios_black_magic_homework
//
//  Created by nero on 2017/2/20.
//  Copyright © 2017年 nero. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Student : NSObject

@property (nonatomic, copy) NSString   *name;

@end
