//
//  XXViewController.m
//  XXShield
//
//  Created by XXShield on 07/10/2017.
//  Copyright (c) 2017 XXShield. All rights reserved.
//

#import "XXViewController.h"

@interface XXViewController ()

@end

@implementation XXViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
