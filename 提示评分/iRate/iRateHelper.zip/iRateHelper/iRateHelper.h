//
//  iRateHelper.h
//  Start
//
//  Created by Mr_Lucky on 2018/9/29.
//  Copyright © 2018 jmw. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface iRateHelper : NSObject

+ (instancetype)shareHelper;

- (void)wb_defaultConfig;

@end

NS_ASSUME_NONNULL_END
