//
//  BadgeViewController.h
//  AxcAE_TabBar
//
//  Created by AxcLogo on 2018/8/27.
//  Copyright © 2018年 AxcLogo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BadgeViewController : UIViewController

@end
