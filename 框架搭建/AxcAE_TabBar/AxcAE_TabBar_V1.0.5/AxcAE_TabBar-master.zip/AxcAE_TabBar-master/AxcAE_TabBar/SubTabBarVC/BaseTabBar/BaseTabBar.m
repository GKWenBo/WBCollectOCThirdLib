//
//  BaseTabBar.m
//  AxcAE_TabBar
//
//  Created by Axc on 2018/6/2.
//  Copyright © 2018年 AxcLogo. All rights reserved.
//

#import "BaseTabBar.h"

@interface BaseTabBar ()

@end

@implementation BaseTabBar

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];

}

@end
