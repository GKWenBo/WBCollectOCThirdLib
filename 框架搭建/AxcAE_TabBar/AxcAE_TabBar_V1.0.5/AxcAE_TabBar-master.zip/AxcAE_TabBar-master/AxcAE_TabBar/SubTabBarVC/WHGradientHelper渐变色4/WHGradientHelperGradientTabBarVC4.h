//
//  WHGradientHelperGradientTabBarVC4.h
//  AxcAE_TabBar
//
//  Created by Axc on 2018/6/4.
//  Copyright © 2018年 AxcLogo. All rights reserved.
//

#import "BaseTabBar.h"

@interface WHGradientHelperGradientTabBarVC4 : BaseTabBar

@end
