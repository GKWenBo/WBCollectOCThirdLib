//
//  VerticalListCollectionView.m
//  JXCategoryView
//
//  Created by jiaxin on 2018/10/10.
//  Copyright © 2018 jiaxin. All rights reserved.
//

#import "VerticalListCollectionView.h"

@implementation VerticalListCollectionView


- (void)layoutSubviews {
    [super layoutSubviews];

    self.layoutSubviewsCallback();
}


@end
