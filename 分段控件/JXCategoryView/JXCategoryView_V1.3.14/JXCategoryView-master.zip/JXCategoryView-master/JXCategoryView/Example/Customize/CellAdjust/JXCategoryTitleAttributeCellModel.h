//
//  JXCategoryTitleAttributeCellModel.h
//  JXCategoryView
//
//  Created by jiaxin on 2018/8/22.
//  Copyright © 2018年 jiaxin. All rights reserved.
//

#import "JXCategoryTitleCellModel.h"

@interface JXCategoryTitleAttributeCellModel : JXCategoryTitleCellModel

@property (nonatomic, copy) NSAttributedString *attributeTitle;
@property (nonatomic, copy) NSAttributedString *selectedAttributeTitle;

@end
