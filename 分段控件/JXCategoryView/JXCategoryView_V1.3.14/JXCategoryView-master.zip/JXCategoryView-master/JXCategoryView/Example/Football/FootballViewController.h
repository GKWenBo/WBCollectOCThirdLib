//
//  FootballViewController.h
//  JXCategoryView
//
//  Created by jiaxin on 2018/8/10.
//  Copyright © 2018年 jiaxin. All rights reserved.
//

#import "ContentBaseViewController.h"

@interface FootballViewController : ContentBaseViewController

@end
