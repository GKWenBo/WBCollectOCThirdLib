//
//  LoadDataListCollectionViewController.h
//  JXCategoryView
//
//  Created by jiaxin on 2019/2/26.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "LoadDataBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface LoadDataListCollectionViewController : LoadDataBaseViewController

@end

NS_ASSUME_NONNULL_END
