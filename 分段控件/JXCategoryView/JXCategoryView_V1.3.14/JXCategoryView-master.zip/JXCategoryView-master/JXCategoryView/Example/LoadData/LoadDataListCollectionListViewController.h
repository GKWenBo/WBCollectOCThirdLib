//
//  LoadDataListCollectionListViewController.h
//  JXCategoryView
//
//  Created by jiaxin on 2019/2/26.
//  Copyright © 2019 jiaxin. All rights reserved.
//

#import "LoadDataListBaseViewController.h"
#import "JXCategoryListCollectionContainerView.h"

NS_ASSUME_NONNULL_BEGIN

@interface LoadDataListCollectionListViewController : LoadDataListBaseViewController <JXCategoryListCollectionContentViewDelegate>

@end

NS_ASSUME_NONNULL_END
