//
//  SGPagingViewPopGestureVC.h
//  SGPagingViewExample
//
//  Created by kingsic on 2018/9/1.
//  Copyright © 2018年 kingsic. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SGPagingViewPopGestureVC : UIViewController

@end
