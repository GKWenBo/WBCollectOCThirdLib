//
//  SGPagingView.h
//  Version 1.6.7
//  GitHub：https://github.com/kingsic/SGPagingView
//
//  Created by kingsic on 2016/10/6.
//  Copyright © 2016年 kingsic. All rights reserved.
//

#import "SGPageTitleViewConfigure.h"
#import "SGPageTitleView.h"
#import "SGPageContentScrollView.h"
#import "SGPageContentCollectionView.h"
#import "SGPagingViewPopGestureVC.h"
