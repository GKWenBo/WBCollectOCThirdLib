//
//  DefaultAttributedTitleVC.h
//  SGPagingViewExample
//
//  Created by kingsic on 2018/5/22.
//  Copyright © 2018年 Sorgle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DefaultAttributedTitleVC : UIViewController

@end
