//
//  DefaultSystemVC.h
//  SGPagingViewExample
//
//  Created by kingsic on 2018/5/14.
//  Copyright © 2018年 Sorgle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DefaultSystemVC : UIViewController

@end
