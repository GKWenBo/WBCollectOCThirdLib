//
//  DefaultAnimatedVC.h
//  SGPagingViewExample
//
//  Created by kingsic on 2018/7/9.
//  Copyright © 2018年 Sorgle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DefaultAnimatedVC : UIViewController

@end
