//
//  DefaultFixedVC.h
//  SGPagingViewExample
//
//  Created by kingsic on 2017/12/7.
//  Copyright © 2017年 Sorgle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DefaultFixedVC : UIViewController

@end
