//
//  DefaultCoverVC.h
//  SGPagingViewExample
//
//  Created by kingsic on 2017/10/17.
//  Copyright © 2017年 Sorgle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DefaultCoverVC : UIViewController

@end
