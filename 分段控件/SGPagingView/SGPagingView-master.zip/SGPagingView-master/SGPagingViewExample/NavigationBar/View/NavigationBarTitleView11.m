//
//  NavigationBarTitleView11.m
//  SGPagingViewExample
//
//  Created by kingsic on 2017/11/1.
//  Copyright © 2017年 Sorgle. All rights reserved.
//

#import "NavigationBarTitleView11.h"

@implementation NavigationBarTitleView11

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
