//
//  NavigationBarTitleView11.h
//  SGPagingViewExample
//
//  Created by kingsic on 2017/11/1.
//  Copyright © 2017年 Sorgle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationBarTitleView11 : UIView

@end
