//
//  ChildVCSix.h
//  SGPageViewExample
//
//  Created by apple on 17/4/19.
//  Copyright © 2017年 Sorgle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChildVCSix : UIViewController

@end
