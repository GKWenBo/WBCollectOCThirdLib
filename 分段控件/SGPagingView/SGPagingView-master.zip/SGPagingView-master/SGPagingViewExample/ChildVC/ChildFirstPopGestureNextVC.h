//
//  ChildFirstPopGestureNextVC.h
//  SGPagingViewExample
//
//  Created by kingsic on 2017/11/28.
//  Copyright © 2017年 Sorgle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SGPagingViewPopGestureVC.h"

@interface ChildFirstPopGestureNextVC : SGPagingViewPopGestureVC

@end
