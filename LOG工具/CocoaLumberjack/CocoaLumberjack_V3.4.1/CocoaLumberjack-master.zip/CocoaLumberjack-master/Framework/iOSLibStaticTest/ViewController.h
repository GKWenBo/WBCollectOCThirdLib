//
//  ViewController.h
//  iOSLibStaticTest
//
//  Created by Andrew Mackenzie-Ross on 3/02/2015.
//
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

