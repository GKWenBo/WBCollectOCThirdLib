//
//  AppDelegate.h
//  iOSLibStaticTest
//
//  Created by Andrew Mackenzie-Ross on 3/02/2015.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

