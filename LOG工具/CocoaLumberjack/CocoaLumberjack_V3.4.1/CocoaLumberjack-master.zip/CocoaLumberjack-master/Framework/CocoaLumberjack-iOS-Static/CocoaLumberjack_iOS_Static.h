//
//  CocoaLumberjack_iOS_Static.h
//  CocoaLumberjack-iOS-Static
//
//  Created by Andrew Mackenzie-Ross on 3/02/2015.
//
//

#import <Foundation/Foundation.h>

@interface CocoaLumberjack_iOS_Static : NSObject

@end
