//
//  CocoaLumberjack_iOS_Static.m
//  CocoaLumberjack-iOS-Static
//
//  Created by Andrew Mackenzie-Ross on 3/02/2015.
//
//

#import "CocoaLumberjack_iOS_Static.h"

@implementation CocoaLumberjack_iOS_Static

@end
