#import <Foundation/Foundation.h>


@interface DynamicLogging : NSObject

+ (void)speedTest0;
+ (void)speedTest1;
+ (void)speedTest2;
+ (void)speedTest3;
+ (void)speedTest4;

@end
