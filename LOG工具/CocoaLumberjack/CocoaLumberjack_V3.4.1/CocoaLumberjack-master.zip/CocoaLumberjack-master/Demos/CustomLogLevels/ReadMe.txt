This Xcode project demonstrates how you can customize the number of log levels, as well as the log level names.  This particular project demonstrates using the following levels:

Fatal
Error
Warn
Notice
Info
Debug

For more information, see the Wiki article:
https://github.com/CocoaLumberjack/CocoaLumberjack/wiki/CustomLogLevels
