#import <Foundation/Foundation.h>
#import <CocoaLumberjack/CocoaLumberjack.h>


@interface TestFormatter : NSObject <DDLogFormatter>

@end
