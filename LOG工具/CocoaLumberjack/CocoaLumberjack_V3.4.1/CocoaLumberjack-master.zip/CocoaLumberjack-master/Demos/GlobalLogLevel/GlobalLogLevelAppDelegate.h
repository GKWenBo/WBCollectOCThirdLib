//
//  GlobalLogLevelAppDelegate.h
//  GlobalLogLevel
//
//  Created by Robbie Hanson on 2/28/11.
//  Copyright 2011 Voalte. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface GlobalLogLevelAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *__unsafe_unretained window;
}

@property (unsafe_unretained) IBOutlet NSWindow *window;

@end
