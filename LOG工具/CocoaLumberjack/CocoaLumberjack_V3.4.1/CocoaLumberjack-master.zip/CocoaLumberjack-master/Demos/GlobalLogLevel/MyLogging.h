#import <CocoaLumberjack/CocoaLumberjack.h>

extern DDLogLevel ddLogLevel;
