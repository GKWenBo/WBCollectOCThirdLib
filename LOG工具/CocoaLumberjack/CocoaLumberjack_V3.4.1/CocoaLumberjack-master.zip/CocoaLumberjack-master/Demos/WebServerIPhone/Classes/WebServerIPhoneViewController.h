#import <UIKit/UIKit.h>


@interface WebServerIPhoneViewController : UIViewController {

}

@end

