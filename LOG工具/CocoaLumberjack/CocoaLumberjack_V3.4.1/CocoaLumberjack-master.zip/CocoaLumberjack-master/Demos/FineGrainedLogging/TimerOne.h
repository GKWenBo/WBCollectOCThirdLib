#import <Cocoa/Cocoa.h>


@interface TimerOne : NSObject
{
    NSTimer *foodTimer;
    NSTimer *sleepTimer;
}

@end
