//
//  main.m
//  FineGrainedLogging
//
//  Created by Robbie Hanson on 5/14/10.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
