#import <Cocoa/Cocoa.h>


@interface TimerTwo : NSObject
{
    NSTimer *foodTimer;
    NSTimer *sleepTimer;
}

@end
