#import <Foundation/Foundation.h>
#import <CocoaLumberjack/CocoaLumberjack.h>


@interface SlowLogger : DDAbstractLogger <DDLogger>


@end
