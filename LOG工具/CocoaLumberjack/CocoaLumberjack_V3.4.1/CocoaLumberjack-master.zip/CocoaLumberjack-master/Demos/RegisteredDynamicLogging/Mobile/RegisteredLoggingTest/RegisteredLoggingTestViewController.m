#import "RegisteredLoggingTestViewController.h"


@implementation RegisteredLoggingTestViewController

@end
