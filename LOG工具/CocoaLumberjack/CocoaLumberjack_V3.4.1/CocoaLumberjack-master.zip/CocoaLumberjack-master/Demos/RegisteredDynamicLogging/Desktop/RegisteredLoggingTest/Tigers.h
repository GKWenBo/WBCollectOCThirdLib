#import <Foundation/Foundation.h>


@interface Tigers : NSObject

+ (void)logStuff;

@end
