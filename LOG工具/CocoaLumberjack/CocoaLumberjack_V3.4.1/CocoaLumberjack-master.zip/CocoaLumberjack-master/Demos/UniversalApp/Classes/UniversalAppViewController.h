//
//  UniversalAppViewController.h
//  UniversalApp
//
//  Created by Robbie Hanson on 7/1/10.
//

#import <UIKit/UIKit.h>

@interface UniversalAppViewController : UIViewController {

}

@end

