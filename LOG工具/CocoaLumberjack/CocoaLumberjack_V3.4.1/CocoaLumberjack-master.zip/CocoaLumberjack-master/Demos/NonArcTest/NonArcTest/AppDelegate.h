//
//  AppDelegate.h
//  NonArcTest
//
//  Created by Robbie Hanson on 11/9/11.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
