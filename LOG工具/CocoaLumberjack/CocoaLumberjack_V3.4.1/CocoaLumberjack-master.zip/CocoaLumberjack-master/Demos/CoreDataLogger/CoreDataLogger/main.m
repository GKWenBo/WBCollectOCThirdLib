//
//  main.m
//  CoreDataLogger
//
//  Created by Robbie Hanson on 3/30/11.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
