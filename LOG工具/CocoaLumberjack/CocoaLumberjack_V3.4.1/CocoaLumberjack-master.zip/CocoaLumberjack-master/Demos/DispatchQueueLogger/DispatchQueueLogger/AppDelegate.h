//
//  AppDelegate.h
//  DispatchQueueLogger
//
//  Created by Robbie Hanson on 11/8/11.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (unsafe_unretained) IBOutlet NSWindow *window;

@end
