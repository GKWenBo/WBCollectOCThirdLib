//
//  AppDelegate.h
//  BenchmarkMac
//
//  Created by Robbie Hanson on 11/15/11.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
