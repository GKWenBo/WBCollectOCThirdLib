This Xcode project provides a benchmarking suite for performance testing on Mac OS X.

Details of the tests, as well as sample results, are provided on the Wiki:
https://github.com/CocoaLumberjack/CocoaLumberjack/wiki/Performance
