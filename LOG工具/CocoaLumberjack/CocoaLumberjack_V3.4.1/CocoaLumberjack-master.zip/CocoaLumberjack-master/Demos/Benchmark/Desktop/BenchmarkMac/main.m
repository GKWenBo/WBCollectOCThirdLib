//
//  main.m
//  BenchmarkMac
//
//  Created by Robbie Hanson on 11/15/11.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
