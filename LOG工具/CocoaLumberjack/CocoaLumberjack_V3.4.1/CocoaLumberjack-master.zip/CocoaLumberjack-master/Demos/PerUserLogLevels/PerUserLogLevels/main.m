//
//  main.m
//  PerUserLogLevels
//
//  Created by Robbie Hanson on 3/30/12.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
