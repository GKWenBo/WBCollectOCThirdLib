//
//  AppDelegate.h
//  PerUserLogLevels
//
//  Created by Robbie Hanson on 3/30/12.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
