//
//  main.m
//  LogFileCompressor
//
//  Created by Robbie Hanson on 5/25/10.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
