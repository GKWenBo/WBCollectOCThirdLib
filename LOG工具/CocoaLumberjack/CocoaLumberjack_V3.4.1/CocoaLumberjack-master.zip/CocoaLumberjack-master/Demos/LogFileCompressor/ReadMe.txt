This Xcode project demonstrates compressing archived log files.  This is done by creating a custom DDLogFileManager, which is part of the DDFileLogger.

For more information, see the Wiki article:
https://github.com/CocoaLumberjack/CocoaLumberjack/wiki/LogFileManagement
