//
//  ViewController.h
//  CaptureASL
//
//  Created by Ernesto Rivera on 2014/03/20.
//
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)log:(id)sender;
- (IBAction)asl_log:(UIButton *)sender;

@end
