//
//  AppDelegate.h
//  CaptureASL
//
//  Created by Ernesto Rivera on 2014/03/20.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

