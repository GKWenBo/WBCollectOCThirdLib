//
//  main.m
//  TestXcodeColors
//
//  Created by Robbie Hanson on 5/17/12.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
