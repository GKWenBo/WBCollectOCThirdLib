#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    IBOutlet UILabel *label;
}

@property (nonatomic, readonly) UILabel *label;

@end
