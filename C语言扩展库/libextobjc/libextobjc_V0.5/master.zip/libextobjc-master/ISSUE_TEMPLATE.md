### Thanks for wanting to contribute to this project!
### Unfortunately, it's not really maintained anymore.

Feel free to use it as-is, or fork it and modify as much as you want to suit your needs.
However, I can't guarantee that I'll have time/energy to look at new issues and pull requests.

Sorry for the trouble!
