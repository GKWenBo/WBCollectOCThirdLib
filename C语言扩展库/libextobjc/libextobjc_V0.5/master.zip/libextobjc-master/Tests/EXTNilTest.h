//
//  EXTNilTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 2011-04-25.
//  Copyright (C) 2012 Justin Spahr-Summers.
//  Released under the MIT license.
//

#import <XCTest/XCTest.h>
#import <Foundation/Foundation.h>
#import "EXTNil.h"

@interface EXTNilTest : XCTestCase {
@private
    
}

@end
