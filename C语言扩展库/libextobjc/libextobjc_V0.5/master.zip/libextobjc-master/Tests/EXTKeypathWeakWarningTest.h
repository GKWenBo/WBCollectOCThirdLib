//
//  EXTKeypathWeakWarningTest.h
//  extobjc
//
//  Created by Javier Soto on 6/23/14.
//
//

#import <XCTest/XCTest.h>
#import "EXTKeyPathCoding.h"

@interface EXTKeypathWeakWarningTest : XCTestCase

@end