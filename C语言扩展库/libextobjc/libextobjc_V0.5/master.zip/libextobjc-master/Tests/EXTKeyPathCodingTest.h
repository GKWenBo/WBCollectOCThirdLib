//
//  EXTKeyPathCodingTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 19.06.12.
//
//

#import <XCTest/XCTest.h>
#import "EXTKeyPathCoding.h"

@interface EXTKeyPathCodingTest : XCTestCase

@end
