//
//  EXTADTTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 19.06.12.
//
//

#import <XCTest/XCTest.h>
#import "EXTADT.h"

@interface EXTADTTest : XCTestCase

@end
