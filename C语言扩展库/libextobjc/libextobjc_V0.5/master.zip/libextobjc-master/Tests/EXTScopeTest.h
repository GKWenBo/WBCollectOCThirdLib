//
//  EXTScopeTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 2011-05-04.
//  Copyright (C) 2012 Justin Spahr-Summers.
//  Released under the MIT license.
//

#import <XCTest/XCTest.h>
#import <Foundation/Foundation.h>
#import "EXTScope.h"

@interface EXTScopeTest : XCTestCase {
@private
    
}

@end
