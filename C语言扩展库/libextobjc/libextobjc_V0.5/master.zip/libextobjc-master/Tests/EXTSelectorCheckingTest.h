//
//  EXTSelectorCheckingTest.h
//  extobjc
//
//  Created by Justin Spahr-Summers on 26.06.12.
//  Copyright (C) 2012 Justin Spahr-Summers.
//  Released under the MIT license.
//

#import <XCTest/XCTest.h>
#import "EXTSelectorChecking.h"

@interface EXTSelectorCheckingTest : XCTestCase

@end
