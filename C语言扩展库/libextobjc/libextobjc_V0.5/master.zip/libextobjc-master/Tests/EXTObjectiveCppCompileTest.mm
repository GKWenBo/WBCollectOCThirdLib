//
//  EXTObjectiveCppCompileTest.mm
//  extobjc
//
//  Created by Igor Kashkuta on 2013-04-01.
//  Released under the MIT license.
//

#import "EXTObjectiveCppCompileTest.h"

@implementation EXTObjectiveCppCompileTest

@end
