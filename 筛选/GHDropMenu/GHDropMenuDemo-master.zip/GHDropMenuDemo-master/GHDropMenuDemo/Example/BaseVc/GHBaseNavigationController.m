//
//  GHBaseNavigationController.m
//  GHDropMenuDemo
//
//  Created by zhaozhiwei on 2019/1/1.
//  Copyright © 2019年 GHome. All rights reserved.
//

#import "GHBaseNavigationController.h"

@interface GHBaseNavigationController ()

@end

@implementation GHBaseNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
}


@end
