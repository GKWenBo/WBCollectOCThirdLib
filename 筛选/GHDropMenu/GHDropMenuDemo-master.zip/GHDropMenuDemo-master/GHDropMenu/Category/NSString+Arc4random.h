//
//  UIView+Arc4random.h
//  XFSSalesSecretary
//
//  Created by mac on 2018/5/19.
//  Copyright © 2018年 http://www.xinfangsheng.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSString (Arc4random)
+ (NSString *)arc4randomStringWithCount: (NSInteger)range minCount: (NSInteger)minCount;
@end
