#import "GPUImageTwoInputFilter.h"

@interface GPUImageDifferenceBlendFilter : GPUImageTwoInputFilter
{
}

@end
