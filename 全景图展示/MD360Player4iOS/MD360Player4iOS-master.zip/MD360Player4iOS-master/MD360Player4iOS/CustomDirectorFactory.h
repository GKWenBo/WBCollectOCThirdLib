//
//  CustomDirectorFactory.h
//  MD360Player4iOS
//
//  Created by Asha on 2018/2/7.
//  Copyright © 2018年 ashqal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MDVRLibrary.h"

@interface CustomDirectorFactory : NSObject<MD360DirectorFactory>
@end
