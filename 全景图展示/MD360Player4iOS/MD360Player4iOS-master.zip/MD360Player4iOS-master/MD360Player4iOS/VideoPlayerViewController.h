//
//  VideoPlayerViewController.h
//  MD360Player4iOS
//
//  Created by ashqal on 16/5/21.
//  Copyright © 2016年 ashqal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PlayerViewController.h"

@interface VideoPlayerViewController : PlayerViewController

@end
