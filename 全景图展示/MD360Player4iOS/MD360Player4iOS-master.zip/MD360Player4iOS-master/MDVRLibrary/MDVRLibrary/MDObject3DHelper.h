//
//  MDObject3DHelper.h
//  MDVRLibrary
//
//  Created by ashqal on 16/7/2.
//  Copyright © 2016年 asha. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MDAbsObject3D.h"

@interface MDObject3DHelper : NSObject
+ (void) loadObj:(MDAbsObject3D*)obj;
@end
