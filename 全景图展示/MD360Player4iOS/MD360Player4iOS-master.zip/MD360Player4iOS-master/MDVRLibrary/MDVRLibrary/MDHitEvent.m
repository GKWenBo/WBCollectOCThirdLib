//
//  MDHitEvent.m
//  MDVRLibrary
//
//  Created by Asha on 2017/5/11.
//  Copyright © 2017年 asha. All rights reserved.
//

#import "MDHitEvent.h"

@implementation MDHitEvent

@end
