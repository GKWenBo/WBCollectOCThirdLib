//
//  MDHitPoint.m
//  MDVRLibrary
//
//  Created by Asha on 2017/5/11.
//  Copyright © 2017年 asha. All rights reserved.
//

#import "MDHitPoint.h"

@implementation MDHitPoint
- (void) asNotHit {}
- (BOOL) isNotHit { return YES; }
@end
