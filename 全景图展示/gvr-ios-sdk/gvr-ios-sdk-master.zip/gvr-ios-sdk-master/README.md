# Google VR SDK for iOS
=====================
Copyright (c) 2016 Google Inc.  All rights reserved.

[https://developers.google.com/vr/ios/get-started.html](https://developers.google.com/vr/ios/get-started.html)
