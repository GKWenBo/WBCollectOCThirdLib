#import <UIKit/UIKit.h>

@interface PanoramaAppDelegate : UIResponder<UIApplicationDelegate>

@property(strong, nonatomic) UIWindow *window;

@end
