#import "PanoramaAppDelegate.h"

#import <UIKit/UIKit.h>

int main(int argc, char * argv[]) {
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([PanoramaAppDelegate class]));
  }
}
