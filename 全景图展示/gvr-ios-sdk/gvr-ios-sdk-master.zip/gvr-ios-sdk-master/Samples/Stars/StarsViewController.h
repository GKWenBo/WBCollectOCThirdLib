#import <GVRKit/GVRKit.h>
#import <UIKit/UIKit.h>

@interface StarsViewController : GVRRendererViewController

@end
