#import <GVRKit/GVRRenderer.h>

/** Stars renderer. */
@interface StarsRenderer : GVRRenderer

@end
