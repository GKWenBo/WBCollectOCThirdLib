#import <UIKit/UIKit.h>

@interface StarsAppDelegate : NSObject
@property(nonatomic, strong) UIWindow* window;
@end
