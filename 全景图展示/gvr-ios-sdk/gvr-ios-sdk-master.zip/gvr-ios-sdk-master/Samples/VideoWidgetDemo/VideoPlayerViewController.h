#import <UIKit/UIKit.h>

@interface VideoPlayerViewController : UIViewController

@end
