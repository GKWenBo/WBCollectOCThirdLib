#import <GVRKit/GVRRenderer.h>

/** TreasureHunt renderer. */
@interface TreasureHuntRenderer : GVRRenderer

- (void)handleTrigger;

@end

