#import <UIKit/UIKit.h>

@interface TreasureHuntAppDelegate : NSObject
@property(nonatomic, strong) UIWindow* window;
@end
