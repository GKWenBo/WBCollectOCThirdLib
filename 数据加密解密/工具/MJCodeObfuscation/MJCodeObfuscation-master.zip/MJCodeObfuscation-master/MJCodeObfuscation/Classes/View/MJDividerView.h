//
//  MJDividerView.h
//  MJCodeObfuscation
//
//  Created by MJ Lee on 2018/8/18.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface MJDividerView : NSView

@end
