//
//  DemoVC1Cell.h
//  XHWebImageHeightLayoutExample
//
//  Created by zhuxiaohui on 2016/11/15.
//  Copyright © 2016年 it7090.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DemoVC1Cell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@end
