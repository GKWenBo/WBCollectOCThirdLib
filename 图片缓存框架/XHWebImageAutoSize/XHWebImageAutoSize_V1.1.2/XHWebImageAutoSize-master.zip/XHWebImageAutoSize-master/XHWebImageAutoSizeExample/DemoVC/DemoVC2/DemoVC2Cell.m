//
//  DemoVC2Cell.m
//  XHWebImageAutoSizeExample
//
//  Created by zhuxiaohui on 2016/11/20.
//  Copyright © 2016年 it7090.com. All rights reserved.
//

#import "DemoVC2Cell.h"
#import "NewsModel.h"

@implementation DemoVC2Cell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
