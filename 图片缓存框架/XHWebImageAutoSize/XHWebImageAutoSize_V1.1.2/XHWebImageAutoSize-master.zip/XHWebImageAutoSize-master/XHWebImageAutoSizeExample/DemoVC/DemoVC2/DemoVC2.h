//
//  DemoVC2.h
//  XHWebImageAutoSizeExample
//
//  Created by zhuxiaohui on 2016/11/20.
//  Copyright © 2016年 it7090.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DemoVC2 : UITableViewController

@end
