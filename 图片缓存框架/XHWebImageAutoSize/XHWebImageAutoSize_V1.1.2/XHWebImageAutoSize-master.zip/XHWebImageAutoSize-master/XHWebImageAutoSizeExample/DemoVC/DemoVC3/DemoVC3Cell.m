//
//  DemoVC3Cell.m
//  XHWebImageAutoSizeExample
//
//  Created by zhuxiaohui on 2016/11/16.
//  Copyright © 2016年 it7090.com. All rights reserved.
//

#import "DemoVC3Cell.h"

@implementation DemoVC3Cell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
