//
//  XHWebImageAutoSizeConst.h
//  XHWebImageAutoSizeExample
//
//  Created by zhuxiaohui on 2017/10/25.
//  Copyright © 2017年 it7090.com. All rights reserved.
//  https://github.com/CoderZhuXH/XHWebImageAutoSize

#import <UIKit/UIKit.h>

#define XHWebImageAutoSizeDeprecated(instead) NS_DEPRECATED(2_0, 2_0, 2_0, 2_0, instead)

#ifdef DEBUG
#define XHDebugLog(...) NSLog(__VA_ARGS__)
#else
#define XHDebugLog(...)
#endif

