
#import <UIKit/UIKit.h>
#import "SCIndexViewConfiguration.h"

@interface SCIndexViewController : UIViewController

@property (nonatomic, assign) SCIndexViewStyle indexViewStyle;
@property (nonatomic, assign) BOOL hasSearch;

@end
