//
//  SectionItem.h
//  iPhoneXDemo
//
//  Created by James on 2018/1/11.
//  Copyright © 2018年 James. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SectionItem : NSObject

@property (nonatomic, strong) NSString *title;
@property (nonatomic, copy) NSArray *items;

@end
