//
//  SecondTableViewCell.h
//  FTPopOverMenu
//
//  Created by liufengting on 16/4/12.
//  Copyright © 2016年 liufengting ( https://github.com/liufengting ). All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *buttonOne;

@property (weak, nonatomic) IBOutlet UIButton *buttonTwo;

@end
