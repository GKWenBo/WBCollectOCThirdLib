//
//  YYWeiboFeedListController.h
//  YYKitExample
//
//  Created by ibireme on 15/9/4.
//  Copyright (c) 2015 ibireme. All rights reserved.
//

#import <UIKit/UIKit.h>

/// 微博列表
@interface WBStatusTimelineViewController : UIViewController

@end
