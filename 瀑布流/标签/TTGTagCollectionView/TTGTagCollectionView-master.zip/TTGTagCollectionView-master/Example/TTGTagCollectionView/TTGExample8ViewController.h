//
//  TTGExample8ViewController.h
//  TTGTagCollectionView_Example
//
//  Created by tutuge on 24/03/2018.
//  Copyright © 2018 zekunyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTGExample8ViewController : UIViewController

@end
