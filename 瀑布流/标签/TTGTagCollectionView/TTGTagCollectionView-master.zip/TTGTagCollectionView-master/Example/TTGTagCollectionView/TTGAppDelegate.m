//
//  TTGAppDelegate.m
//  TTGTagCollectionView
//
//  Created by zekunyan on 12/11/2015.
//  Copyright (c) 2015 zekunyan. All rights reserved.
//

#import "TTGAppDelegate.h"

@implementation TTGAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}

@end
