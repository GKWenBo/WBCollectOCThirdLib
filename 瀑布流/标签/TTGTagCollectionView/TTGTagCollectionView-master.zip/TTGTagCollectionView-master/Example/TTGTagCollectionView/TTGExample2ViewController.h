//
//  TTGExample2ViewController.h
//  TTGTagCollectionView
//
//  Created by zorro on 15/12/29.
//  Copyright © 2015年 zekunyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTGExample2ViewController : UIViewController

@end
