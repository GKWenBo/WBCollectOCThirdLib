//
//  TTGExample6ViewController.h
//  TTGTagCollectionView
//
//  Created by tutuge on 2017/3/2.
//  Copyright © 2017年 zekunyan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTGExample6ViewController : UIViewController

@end
