//
//  main.m
//  TTGTagCollectionView
//
//  Created by zekunyan on 12/11/2015.
//  Copyright (c) 2015 zekunyan. All rights reserved.
//

@import UIKit;
#import "TTGAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TTGAppDelegate class]));
    }
}
