//
//  TTGAppDelegate.h
//  TTGTagCollectionView
//
//  Created by zekunyan on 12/11/2015.
//  Copyright (c) 2015 zekunyan. All rights reserved.
//

@import UIKit;

@interface TTGAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
