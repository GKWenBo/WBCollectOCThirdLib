# QMUIDemo_iOS
Sample Code for QMUI iOS https://github.com/Tencent/QMUI_iOS

支持 iOS 版本：iOS 8.0+

## 关于 GitHub 版本和 AppStore 版本

之前 QMUI Demo 也同时发布在 AppStore 上，后来由于苹果审核原因，Demo 性质的 App 不允许上架，因此 AppStore 的版本停留在 1.7.2，短期内也无计划更新。若想体验最新版本的 QMUI Demo，请自行拉取 GitHub 项目代码运行。
