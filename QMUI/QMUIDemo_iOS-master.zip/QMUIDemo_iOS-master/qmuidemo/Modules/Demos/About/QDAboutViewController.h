//
//  QDAboutViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 2016/11/5.
//  Copyright © 2016年 QMUI Team. All rights reserved.
//

#import "QDCommonViewController.h"

@interface QDAboutViewController : QDCommonViewController

@end
