//
//  QDLabViewController.h
//  qmui
//
//  Created by QMUI Team on 14/11/5.
//  Copyright (c) 2014年 QMUI Team. All rights reserved.
//

#import "QDCommonListViewController.h"

@interface QDLabViewController : QDCommonListViewController

@end
