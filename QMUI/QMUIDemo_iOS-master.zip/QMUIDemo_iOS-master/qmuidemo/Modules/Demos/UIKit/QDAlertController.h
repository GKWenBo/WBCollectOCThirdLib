//
//  QDAlertController.h
//  qmuidemo
//
//  Created by QMUI Team on 15/7/20.
//  Copyright (c) 2015年 QMUI Team. All rights reserved.
//

#import "QDCommonGroupListViewController.h"

@interface QDAlertController : QDCommonGroupListViewController

@end
