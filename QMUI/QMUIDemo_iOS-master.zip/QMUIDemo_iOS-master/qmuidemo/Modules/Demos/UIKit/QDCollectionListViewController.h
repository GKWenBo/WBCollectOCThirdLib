//
//  QDCollectionListViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 15/9/24.
//  Copyright © 2015年 QMUI Team. All rights reserved.
//

#import "QDCommonListViewController.h"

@interface QDCollectionListViewController : QDCommonListViewController

@end
