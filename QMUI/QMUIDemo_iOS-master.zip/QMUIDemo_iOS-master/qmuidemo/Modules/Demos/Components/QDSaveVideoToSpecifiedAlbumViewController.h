//
//  QDSaveVideoToSpecifiedAlbumViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 15/6/10.
//  Copyright (c) 2015年 QMUI Team. All rights reserved.
//

#import "QDCommonViewController.h"

@interface QDSaveVideoToSpecifiedAlbumViewController : QDCommonViewController

@end
