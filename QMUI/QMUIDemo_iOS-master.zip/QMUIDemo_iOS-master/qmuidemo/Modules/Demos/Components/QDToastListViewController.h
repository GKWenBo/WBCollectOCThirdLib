//
//  QDToastListViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 2016/12/13.
//  Copyright © 2016年 QMUI Team. All rights reserved.
//

#import "QDCommonListViewController.h"

@interface QDToastListViewController : QDCommonListViewController

@end
