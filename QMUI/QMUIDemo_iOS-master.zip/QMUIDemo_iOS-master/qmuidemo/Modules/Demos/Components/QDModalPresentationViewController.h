//
//  QDModalPresentationViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 16/7/20.
//  Copyright © 2016年 QMUI Team. All rights reserved.
//

#import "QDCommonListViewController.h"
#import "QDCommonGroupListViewController.h"

@interface QDModalPresentationViewController : QDCommonGroupListViewController

@end
