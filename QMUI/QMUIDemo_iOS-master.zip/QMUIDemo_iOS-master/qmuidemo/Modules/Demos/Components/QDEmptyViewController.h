//
//  QDEmptyViewController.h
//  qmui
//
//  Created by QMUI Team on 14-7-3.
//  Copyright (c) 2014年 QMUI Team. All rights reserved.
//

#import "QDCommonTableViewController.h"

@interface QDEmptyViewController : QDCommonTableViewController

@end
