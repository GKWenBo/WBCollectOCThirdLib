//
//  QDImagePreviewViewController1.h
//  qmuidemo
//
//  Created by QMUI Team on 2016/12/6.
//  Copyright © 2016年 QMUI Team. All rights reserved.
//

#import "QDCommonViewController.h"

@interface QDImagePreviewViewController1 : QDCommonViewController

@end
