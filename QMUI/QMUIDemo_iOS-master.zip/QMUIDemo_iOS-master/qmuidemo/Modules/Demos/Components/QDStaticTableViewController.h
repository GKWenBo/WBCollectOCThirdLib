//
//  QDStaticTableViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 15/5/3.
//  Copyright (c) 2015年 QMUI Team. All rights reserved.
//

#import "QDCommonTableViewController.h"

@interface QDStaticTableViewController : QDCommonTableViewController

@end
