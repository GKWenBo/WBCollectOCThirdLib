//
//  QDMultipleDelegatesViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 2018/3/28.
//  Copyright © 2018年 QMUI Team. All rights reserved.
//

#import "QDCommonViewController.h"

@interface QDMultipleDelegatesViewController : QDCommonViewController

@end
