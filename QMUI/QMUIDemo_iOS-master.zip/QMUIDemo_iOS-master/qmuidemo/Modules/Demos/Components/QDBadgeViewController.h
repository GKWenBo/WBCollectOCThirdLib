//
//  QDBadgeViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 2018/6/2.
//  Copyright © 2018年 QMUI Team. All rights reserved.
//

#import "QDCommonListViewController.h"

@interface QDBadgeViewController : QDCommonListViewController

@end
