//
//  QDNavigationTitleViewController.h
//  qmui
//
//  Created by QMUI Team on 14-7-2.
//  Copyright (c) 2014年 QMUI Team. All rights reserved.
//

#import "QDCommonListViewController.h"

@interface QDNavigationTitleViewController : QDCommonListViewController

@end
