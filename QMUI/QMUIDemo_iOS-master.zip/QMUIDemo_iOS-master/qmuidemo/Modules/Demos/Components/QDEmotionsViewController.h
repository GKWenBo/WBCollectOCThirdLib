//
//  QDEmotionsViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 16/9/6.
//  Copyright © 2016年 QMUI Team. All rights reserved.
//

#import "QDCommonViewController.h"

@interface QDEmotionsViewController : QDCommonViewController

@end
