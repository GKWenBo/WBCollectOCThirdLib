//
//  QDCommonViewController.h
//  qmuidemo
//
//  Created by QMUI Team on 15/4/13.
//  Copyright (c) 2015年 QMUI Team. All rights reserved.
//

#import "QDThemeProtocol.h"

@interface QDCommonViewController : QMUICommonViewController <QDChangingThemeDelegate>

@end
