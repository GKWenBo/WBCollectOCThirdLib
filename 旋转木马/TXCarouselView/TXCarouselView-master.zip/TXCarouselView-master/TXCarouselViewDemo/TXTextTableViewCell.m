//
//  TXTextTableViewCell.m
//  textView
//
//  Created by 新华龙mac on 2018/1/19.
//  Copyright © 2018年 新华龙mac. All rights reserved.
//

#import "TXTextTableViewCell.h"

@implementation TXTextTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
