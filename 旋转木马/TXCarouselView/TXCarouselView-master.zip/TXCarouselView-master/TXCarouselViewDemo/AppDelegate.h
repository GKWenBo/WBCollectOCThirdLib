//
//  AppDelegate.h
//  TXCarouselViewDemo
//
//  Created by 新华龙mac on 2018/1/31.
//  Copyright © 2018年 新华龙mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

