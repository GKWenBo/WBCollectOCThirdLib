//
//  TXTextTableViewCell.h
//  textView
//
//  Created by 新华龙mac on 2018/1/19.
//  Copyright © 2018年 新华龙mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TXTextTableViewCell : UITableViewCell

@end
