//
//  TXCarouselCellModel.h
//  textView
//
//  Created by 新华龙mac on 2018/1/10.
//  Copyright © 2018年 新华龙mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface TXCarouselCellModel : NSObject
@property (nonatomic, assign) NSInteger newsId;
@property (nonatomic, strong) NSString *titleStr;
@property (nonatomic, strong) NSString *imageUrl;
@end
