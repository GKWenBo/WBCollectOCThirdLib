//
//  TLEmojiFaceItemCell.h
//  TLChat
//
//  Created by 李伯坤 on 16/3/9.
//  Copyright © 2016年 李伯坤. All rights reserved.
//

#import "TLEmojiBaseCell.h"


@interface TLEmojiFaceItemCell : TLEmojiBaseCell

@end
