//
//  TLEmojiImageTitleItemCell.h
//  TLChat
//
//  Created by 李伯坤 on 16/2/21.
//  Copyright © 2016年 李伯坤. All rights reserved.
//

#import "TLEmojiBaseCell.h"


@interface TLEmojiImageTitleItemCell : TLEmojiBaseCell


@end
