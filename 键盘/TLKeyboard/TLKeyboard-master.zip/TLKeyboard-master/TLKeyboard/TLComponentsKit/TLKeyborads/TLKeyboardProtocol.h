//
//  TLKeyboardProtocol.h
//  TLChat
//
//  Created by 李伯坤 on 16/8/8.
//  Copyright © 2016年 李伯坤. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol TLKeyboardProtocol <NSObject>

@required
;
- (CGFloat)keyboardHeight;

@end
