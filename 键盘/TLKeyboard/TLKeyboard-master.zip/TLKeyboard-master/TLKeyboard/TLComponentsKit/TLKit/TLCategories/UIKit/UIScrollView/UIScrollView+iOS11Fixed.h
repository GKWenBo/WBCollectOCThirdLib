//
//  UIScrollView+iOS11Fixed.h
//  TLChat
//
//  Created by 李伯坤 on 2017/11/9.
//  Copyright © 2017年 lbk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (iOS11Fixed)

@property (nonatomic, assign) BOOL neverAdjustmentContentInset;

@end
