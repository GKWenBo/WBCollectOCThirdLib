//
//  UITextView+LengthLimit.h
//  Pods
//
//  Created by 李伯坤 on 2017/9/11.
//
//

#import <UIKit/UIKit.h>

@interface UITextView (LengthLimit)

@property (assign, nonatomic) NSInteger maxLength;

@end
