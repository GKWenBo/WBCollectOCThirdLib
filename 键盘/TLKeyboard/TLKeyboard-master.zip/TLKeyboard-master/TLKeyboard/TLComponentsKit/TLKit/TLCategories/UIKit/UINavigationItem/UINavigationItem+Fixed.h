//
//  UINavigationItem+Fixed.h
//  TLChat
//
//  Created by 李伯坤 on 16/3/4.
//  Copyright © 2016年 李伯坤. All rights reserved.
//
//  调整navBar的barButton间距
//

#import <UIKit/UIKit.h>

#define     NAVBAR_ITEM_FIXED_SPACE     5.0f

@interface UINavigationItem (Fixed)

@end
