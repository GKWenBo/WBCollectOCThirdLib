//
//  UICollectionViewCell+Extensions.h
//  TLChat
//
//  Created by 李伯坤 on 2017/7/17.
//  Copyright © 2017年 李伯坤. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UICollectionViewCell (Extensions)

/// 高亮色
@property (nonatomic, strong) UIColor *selectedBackgrounColor;

@end
