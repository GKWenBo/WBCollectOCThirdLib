# TLKeyboard

[![CI Status](https://img.shields.io/travis/xieyingliang/TLKeyboard.svg?style=flat)](https://travis-ci.org/xieyingliang/TLKeyboard)
[![Version](https://img.shields.io/cocoapods/v/TLKeyboard.svg?style=flat)](https://cocoapods.org/pods/TLKeyboard)
[![License](https://img.shields.io/cocoapods/l/TLKeyboard.svg?style=flat)](https://cocoapods.org/pods/TLKeyboard)
[![Platform](https://img.shields.io/cocoapods/p/TLKeyboard.svg?style=flat)](https://cocoapods.org/pods/TLKeyboard)


##  Note
此Demo是整合TLChat的代码修改完成的。（内附了cocoaPods的spec模板，项目分层只是为了pods库美观。没有细分子库的依赖关系，单独安装子库可能会有问题）


## Preview 
![image](https://github.com/ylxieg/TLKeyboard/blob/master/example.gif)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

TLKeyboard is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'TLKeyboard'
```

## Author

xieyingliang, 744890760@qq.com

## License

TLKeyboard is available under the MIT license. See the LICENSE file for more info.
