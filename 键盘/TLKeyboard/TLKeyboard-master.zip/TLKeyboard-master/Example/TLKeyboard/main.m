//
//  main.m
//  TLKeyboard
//
//  Created by xieyingliang on 12/24/2018.
//  Copyright (c) 2018 xieyingliang. All rights reserved.
//

@import UIKit;
#import "TLAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TLAppDelegate class]));
    }
}
