//
//  TLAppDelegate.h
//  TLKeyboard
//
//  Created by xieyingliang on 12/24/2018.
//  Copyright (c) 2018 xieyingliang. All rights reserved.
//

@import UIKit;

@interface TLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
