//
//  SCLAlertViewFramework.h
//  SCLAlertView
//
//  Created by Eugene Tulusha on 9/13/16.
//  Copyright © 2016 AnyKey Entertainment. All rights reserved.
//

@import Foundation;

//! Project version number for CryptoSwift.
FOUNDATION_EXPORT double SCLAlertViewFrameworkVersionNumber;

//! Project version string for CryptoSwift.
FOUNDATION_EXPORT const unsigned char SCLAlertViewFrameworkVersionString[];

#import "SCLAlertView.h"
