- [ ] I have verified there are no duplicate active or recent bugs, questions, or requests

###### Include the following:
 - SCLAlertView version: `1.0.3`
 - Device OS version: `6.0`
 - Device Name: `iPhone 6`
 
###### Reproduction Steps
 1.
 2.
 3.

###### Expected Result

###### Actual Result

### Tell us what could be improved:
