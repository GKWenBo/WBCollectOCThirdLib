//
//  JGMainViewController.h
//  JGProgressHUD Tests
//
//  Created by Jonas Gessner on 20.07.14.
//  Copyright (c) 2014 Jonas Gessner. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JGMainViewController : UITableViewController

@end
