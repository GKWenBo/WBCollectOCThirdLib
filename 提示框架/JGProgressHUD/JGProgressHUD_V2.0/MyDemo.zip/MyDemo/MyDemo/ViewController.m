//
//  ViewController.m
//  MyDemo
//
//  Created by WMB on 2017/10/26.
//  Copyright © 2017年 WMB. All rights reserved.
//

#import "ViewController.h"
#import <JGProgressHUD.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
//
//    JGProgressHUD *HUD = [JGProgressHUD progressHUDWithStyle:JGProgressHUDStyleExtraLight];
//    HUD.textLabel.text = @"Loading";
//    [HUD showInView:self.view];
//    [HUD dismissAfterDelay:3.0];
    
    JGProgressHUD *HUD = [JGProgressHUD progressHUDWithStyle:JGProgressHUDStyleDark];
    HUD.textLabel.text = @"Error";
    HUD.indicatorView = [[JGProgressHUDErrorIndicatorView alloc] init]; //JGProgressHUDSuccessIndicatorView is also available
    [HUD showInView:self.view];
    [HUD dismissAfterDelay:3.0];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
