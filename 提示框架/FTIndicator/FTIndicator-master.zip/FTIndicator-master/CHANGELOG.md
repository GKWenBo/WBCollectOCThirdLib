# FTIndicator ChangeLog

| Version | Date | ChangeLog |
| :--------: | :--------: | :-------- |
|1.0.0|2016.07.31|upload to CocoaPods|
|1.0.9|2016.08.02|add status bar frame observe for notification|
|1.1.0|2016-08-12|add notification tap handler thanks to Yuli Chandra|
|1.1.1|2016-08-15|Add notification completion handler thanks to Yuli Chandra|
|1.1.2|2016-08-15|fix bugs when no text|
|1.1.3|2016-08-28|progress hud add user interaction disable|
|1.1.4|2016-09-08|fix a bug where load image from bundle not working|
|1.1.5|2016-09-20|fix: podspec doest not correctly link to "FTToastIndicator"|
|1.1.6|2016-11-22|fix a bug of not dismissing when user back to homescreen，remove subpods|
|1.1.7|2017-01-13|add NotificationIndicator only manually dismiss support|
|1.1.8|2017-02-09|fix: Spinner disappearance stutters|
|1.1.9|2017-03-14|Sorry I forget what it is about.|
|1.2.0|2017-03-14|major fix: progress HUD doesn't show when app starts|
|1.2.1|2017-07-11|fix weak issue|
|1.2.2|2017-08-07|fix syntax error, may cause syntax errors for your projects|
|1.2.3|2017-09-07|bqlin: fix progressView can not didmiss bug，fix issuce #8|
|1.2.4|2017-09-08|bqlin - fix issues #8.|
|1.2.5|2017-09-10|fix keyboard animation|
|1.2.6|2017-10-25|fix not dismiss issue|
|1.2.7|2018-04-10|RealBonus: FTNotification: default dismiss time|
|1.2.8|2018-04-18|fix: keyboard height issue|
|1.2.9|2018-05-14|change animations|


