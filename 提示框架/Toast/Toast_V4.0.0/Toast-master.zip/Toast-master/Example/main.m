//
//  main.m
//  ToastTest
//
//  Copyright 2014 Charles Scalesse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CSAppDelegate.h"

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CSAppDelegate class]));
    }
}