//
//  AppDelegate.h
//  JXTAlertManagerDemo
//
//  Created by JXT on 2016/12/21.
//  Copyright © 2016年 JXT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

