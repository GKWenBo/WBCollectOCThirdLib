//
//  STImageController.h
//  SwipeTableView
//
//  Created by Roy lee on 16/6/24.
//  Copyright © 2016年 Roy lee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STImageController : UIViewController

@property (nonatomic, strong) UIImageView *imageView;

@end
