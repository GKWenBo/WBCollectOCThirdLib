//
//  Swift-Bridge-Objective-C.h
//  JXPagingView
//
//  Created by jiaxin on 2018/5/29.
//  Copyright © 2018年 jiaxin. All rights reserved.
//

#import "JXCategoryView.h"
#import "MJRefresh.h"
