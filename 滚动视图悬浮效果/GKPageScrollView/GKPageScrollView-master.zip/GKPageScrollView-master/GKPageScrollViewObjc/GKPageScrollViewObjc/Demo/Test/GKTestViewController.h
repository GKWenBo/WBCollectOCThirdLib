//
//  GKTestViewController.h
//  GKPageScrollViewDemo
//
//  Created by gaokun on 2018/12/6.
//  Copyright © 2018 QuintGao. All rights reserved.
//

#import "GKDemoBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GKTestViewController : GKDemoBaseViewController

@end

NS_ASSUME_NONNULL_END
