//
//  GKWBViewController.h
//  GKPageScrollView
//
//  Created by QuintGao on 2018/10/27.
//  Copyright © 2018 QuintGao. All rights reserved.
//

#import "GKDemoBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GKWBViewController : GKDemoBaseViewController

@end

NS_ASSUME_NONNULL_END
