//
//  GKMainRefreshViewController.h
//  GKPageScrollViewDemo
//
//  Created by gaokun on 2018/12/11.
//  Copyright © 2018 QuintGao. All rights reserved.
//

#import "GKBasePageViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface GKMainRefreshViewController : GKBasePageViewController

@end

NS_ASSUME_NONNULL_END
