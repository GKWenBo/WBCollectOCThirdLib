//
//  ViewController.h
//  GKPageScrollViewObjc
//
//  Created by gaokun on 2019/2/20.
//  Copyright © 2019 gaokun. All rights reserved.
//

#import "GKDemoBaseViewController.h"

@interface ViewController : GKDemoBaseViewController


@end

