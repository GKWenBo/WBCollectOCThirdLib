//
//  main.m
//  MailAppDemo
//
//  Created by Imanol Fernandez Gorostizaga on 26/09/14.
//  Copyright (c) 2014 Mortimer. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
