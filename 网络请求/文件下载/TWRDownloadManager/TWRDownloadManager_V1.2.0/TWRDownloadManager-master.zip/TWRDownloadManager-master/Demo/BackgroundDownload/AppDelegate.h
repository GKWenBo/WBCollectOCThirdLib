//
//  AppDelegate.h
//  BackgroundDownload
//
//  Created by Michelangelo Chasseur on 13/09/14.
//  Copyright (c) 2014 Touchware. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

