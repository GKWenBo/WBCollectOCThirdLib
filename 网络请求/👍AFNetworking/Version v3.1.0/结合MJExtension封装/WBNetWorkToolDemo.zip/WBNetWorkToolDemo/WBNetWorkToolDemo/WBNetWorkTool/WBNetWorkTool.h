//
//  WBNetWorkTool.h
//  WBNetWorkToolDemo
//
//  Created by WMB on 2017/11/12.
//  Copyright © 2017年 WMB. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "AFNetworking.h"
#import "MJExtension.h"

/** << 请求成功失败Block回调 > */
typedef void(^WBReponseCompletedBlock)(NSInteger status, id responseObject, NSInteger totalPage);
typedef void(^WBResponseFailureBlock)(NSError *error);
typedef void(^WBDownloadResponseBlock)(id responseObject);
/** << 返回model对象Block回调 > */
typedef void(^WBResponseConvertToModelBlock)(NSInteger status, id responseObject, NSObject *modelObject, NSInteger totalPage);
/**
 模型数组转换回调

 @param status 请求状态码
 @param responseObject 请求返回数据
 @param modelArray 模型数组
 @param totalPage 总页数 默认为0
 */
typedef void(^WBResponseConvertToModelArrayBlock)(NSInteger status, id responseObject, NSArray *modelArray, NSInteger totalPage);
/**
 Download progress

 @param bytesRead already completed
 @param totalBytesRead total bytes
 */
typedef void(^WBDownloadProgress)(int64_t bytesRead, int64_t totalBytesRead);

/**
 Upload progress

 @param bytesWritten 已上传大小
 @param totalBytesWritten 上传文件总大小
 */
typedef void(^WBUploadProgress)(int64_t bytesWritten,int64_t totalBytesWritten);

/** << 网络状态枚举 > */
typedef NS_ENUM(NSInteger, WBNetWorkReachabilityStatus) {
    WBNetWorkReachabilityStatusUnknown = - 1,       /** << 未知网络 > */
    WBNetWorkReachabilityStatusNotReachable = 0,    /** << 没有网络 > */
    WBNetWorkReachabilityStatusViaWWAN = 1,         /** << 手机自带网络 > */
    WBNetWorkReachabilityStatusViaWiFi = 2          /** << wifi > */
};

/** << 请求状态枚举 > */
typedef NS_ENUM(NSInteger, WBResponseStatusCode) {
    WBResponseStatusSuccessCode,                /** << 请求成功 > */
    WBResponseStatusAuthenticationFailedCode    /** << 鉴权失败 > */
};

/** << 请求服务器基地址 > */
UIKIT_EXTERN NSString *const kWBBaseRequestUrl;
/** << 请求状态码key > */
UIKIT_EXTERN NSString *const kWBResponseStatusCodeKey;
/** << 请求数据总分页数key > */
UIKIT_EXTERN NSString *const kWBResponseTotalPageKey;
/** << 服务器返回状态信息key > */
UIKIT_EXTERN NSString *const kWBResponseMsgKey;
/** << 服务器返回数据key > */
UIKIT_EXTERN NSString *const kWBResponseDataKey;

/** << 简便宏 > */
#define kWBNetWorkTool [WBNetWorkTool shareNetWorkTool]

@interface WBNetWorkTool : NSObject

/**
 单例管理类

 @return WBNetWorkTool
 */
+ (instancetype)shareNetWorkTool;

/** << 网络状态 > */
@property (nonatomic, assign) WBNetWorkReachabilityStatus netWorkStatus;
/** << 请求超时时间 默认20s > */
@property (nonatomic, assign) NSTimeInterval timeoutInterval;

#pragma mark ------ < Base Request Method > ------
#pragma mark
/**
 GET请求 返回NSURLSessionDataTask方便管理

 @param urlString   接口地址
 @param parameters  请求参数
 @param completed   请求成功回调
 @param failure     请求失败回调
 @return            NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_startGETRequestWithUrlString:(NSString *)urlString
                                               parameters:(NSDictionary *)parameters
                                                completed:(WBReponseCompletedBlock)completed
                                                  failure:(WBResponseFailureBlock)failure;

/**
 POST请求 返回NSURLSessionDataTask方便管理
 
 @param urlString   接口地址
 @param parameters  请求参数
 @param completed   请求成功回调
 @param failure     请求失败回调
 @return            NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_startPOSTRequestWithUrlString:(NSString *)urlString
                                                parameters:(NSDictionary *)parameters
                                                 completed:(WBReponseCompletedBlock)completed
                                                   failure:(WBResponseFailureBlock)failure;

/**
 DELETE请求 返回NSURLSessionDataTask方便管理
 
 @param urlString   接口地址
 @param parameters  请求参数
 @param completed   请求成功回调
 @param failure     请求失败回调
 @return            NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_startDELETERequestWithUrlString:(NSString *)urlString
                                                  parameters:(NSDictionary *)parameters
                                                   completed:(WBReponseCompletedBlock)completed
                                                     failure:(WBResponseFailureBlock)failure;
/**
 PUT请求 返回NSURLSessionDataTask方便管理
 
 @param urlString   接口地址
 @param parameters  请求参数
 @param completed   请求成功回调
 @param failure     请求失败回调
 @return            NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_startPUTRequestWithUrlString:(NSString *)urlString
                                               parameters:(NSDictionary *)parameters
                                                completed:(WBReponseCompletedBlock)completed
                                                  failure:(WBResponseFailureBlock)failure;
/**
 PATCH请求 返回NSURLSessionDataTask方便管理
 
 @param urlString   接口地址
 @param parameters  请求参数
 @param completed   请求成功回调
 @param failure     请求失败回调
 @return            NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_startPATCHRequestWithUrlString:(NSString *)urlString
                                                 parameters:(NSDictionary *)parameters
                                                  completed:(WBReponseCompletedBlock)completed
                                                    failure:(WBResponseFailureBlock)failure;

#pragma mark ------ < Return Model Request Method > ------
#pragma mark
/**
 GET请求 返回Model对象

 @param urlString   接口地址
 @param parameters  请求参数
 @param modelClass  model类型
 @param completed   请求成功回调
 @param failure     请求失败回调
 @return            NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_startGETRequestModelWithUrlString:(NSString *)urlString
                                                    parameters:(NSDictionary *)parameters
                                                    modelClass:(Class)modelClass
                                                     completed:(WBResponseConvertToModelBlock)completed
                                                       failure:(WBResponseFailureBlock)failure;
/**
 GET请求 返回ModelArray对象
 
 @param urlString   接口地址
 @param parameters  请求参数
 @param modelClass  model类型
 @param completed   请求成功回调
 @param failure     请求失败回调
 @return            NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_startGETRequestModelArrayWithUrlString:(NSString *)urlString
                                                         parameters:(NSDictionary *)parameters
                                                         modelClass:(Class)modelClass
                                                          completed:(WBResponseConvertToModelArrayBlock)completed
                                                            failure:(WBResponseFailureBlock)failure;

/**
 POST请求 返回Model对象
 
 @param urlString   接口地址
 @param parameters  请求参数
 @param modelClass  model类型
 @param completed   请求成功回调
 @param failure     请求失败回调
 @return            NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_startPOSTRequestModelWithUrlString:(NSString *)urlString
                                                     parameters:(NSDictionary *)parameters
                                                     modelClass:(Class)modelClass
                                                      completed:(WBResponseConvertToModelBlock)completed
                                                        failure:(WBResponseFailureBlock)failure;
/**
 POST请求 返回ModelArray对象
 
 @param urlString   接口地址
 @param parameters  请求参数
 @param modelClass  model类型
 @param completed   请求成功回调
 @param failure     请求失败回调
 @return            NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_startPOSTRequestModelArrayWithUrlString:(NSString *)urlString
                                                          parameters:(NSDictionary *)parameters
                                                          modelClass:(Class)modelClass
                                                           completed:(WBResponseConvertToModelArrayBlock)completed
                                                             failure:(WBResponseFailureBlock)failure;

#pragma mark ------ < 上传图片 > ------
#pragma mark
/**
 上传多张图片封装

 @param urlString 接口地址
 @param parameters 上传参数
 @param imageArray 要上传的图片数组
 @param name 与指定的图片相关联的名称，这是由后端写接口的人指定的
 @param progress 进度回调
 @param completed 完成回调
 @param failure 失败回调
 @return NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_uploadImagesWithUrlString:(NSString *)urlString
                                            parameters:(NSDictionary *)parameters
                                            imageArray:(NSArray *)imageArray
                                                  name:(NSString *)name
                                              progress:(WBUploadProgress)progress
                                             completed:(WBReponseCompletedBlock)completed
                                               failure:(WBResponseFailureBlock)failure;
/**
 单张图片封装
 
 @param urlString 接口地址
 @param parameters 上传参数
 @param image 要上传的图片
 @param name 与指定的图片相关联的名称，这是由后端写接口的人指定的
 @param progress 进度回调
 @param completed 完成回调
 @param failure 失败回调
 @return NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_uploadImagesWithUrlString:(NSString *)urlString
                                            parameters:(NSDictionary *)parameters
                                                 image:(NSArray *)image
                                                  name:(NSString *)name
                                              progress:(WBUploadProgress)progress
                                             completed:(WBReponseCompletedBlock)completed
                                               failure:(WBResponseFailureBlock)failure;

/**
 上传多张图片根据文件路径

 @param urlString 接口地址
 @param parameters 上传参数
 @param imageUrlArray 要上传的图片路径数组
 @param name 与指定的图片相关联的名称，这是由后端写接口的人指定的
 @param progress 进度回调
 @param completed 完成回调
 @param failure  失败回调
 @return NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_uploadImagesWithUrlString:(NSString *)urlString
                                            parameters:(NSDictionary *)parameters
                                         imageUrlArray:(NSArray *)imageUrlArray
                                                  name:(NSString *)name
                                              progress:(WBUploadProgress)progress
                                             completed:(WBReponseCompletedBlock)completed
                                               failure:(WBResponseFailureBlock)failure;
/**
 单张图片根据文件路径
 
 @param urlString 接口地址
 @param parameters 上传参数
 @param imageUrl 要上传的图片路径
 @param name 与指定的图片相关联的名称，这是由后端写接口的人指定的
 @param progress 进度回调
 @param completed 完成回调
 @param failure  失败回调
 @return NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_uploadImagesWithUrlString:(NSString *)urlString
                                            parameters:(NSDictionary *)parameters
                                              imageUrl:(NSArray *)imageUrl
                                                  name:(NSString *)name
                                              progress:(WBUploadProgress)progress
                                             completed:(WBReponseCompletedBlock)completed
                                               failure:(WBResponseFailureBlock)failure;


#pragma mark ------ < 下载文件 > ------
#pragma mark
/**
 下载文件方法

 @param url 文件接口地址
 @param saveFilePath 要保存的地址
 @param progress 下载进度回调
 @param completed 完成回调
 @param failure 失败回调
 */
- (NSURLSessionDownloadTask *)wb_downloadWithUrl:(NSString *)url
                                    saveFilePath:(NSString *)saveFilePath
                                        progress:(WBDownloadProgress)progress
                                       completed:(WBDownloadResponseBlock)completed
                                         failure:(WBResponseFailureBlock)failure;


#pragma mark ------ < 网络状态监测 > ------
#pragma mark
/**
 Start monitoring network status
 */
- (void)wb_startMonitoring;

#pragma mark ------ < Cancle Request > ------
#pragma mark
/**
 根据接口地址取消请求

 @param urlString 接口地址
 */
- (void)wb_cancleRequestWithUrlString:(NSString *)urlString;
/**
 取消所有网络请求
 */
- (void)wb_cancleAllRequest;

@end
