//
//  ViewController.m
//  WBNetWorkToolDemo
//
//  Created by WMB on 2017/11/12.
//  Copyright © 2017年 WMB. All rights reserved.
//

#import "ViewController.h"
#import "WBNetWorkTool.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [kWBNetWorkTool wb_startPOSTRequestWithUrlString:@"11" parameters:@{} completed:^(NSInteger status, id responseObject, NSInteger totalPage) {
        
    } failure:^(NSError *error) {
        
    }];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
