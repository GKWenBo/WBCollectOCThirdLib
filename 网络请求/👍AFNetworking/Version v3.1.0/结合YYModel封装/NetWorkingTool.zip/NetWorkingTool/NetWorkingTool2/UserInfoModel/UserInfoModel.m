//
//  UserInfoModel.m
//  NetWorkingTool2
//
//  Created by WMB on 2016/12/9.
//  Copyright © 2016年 文波. All rights reserved.
//

#import "UserInfoModel.h"
#import "YYModel.h"
static NSString *const kUserInfoKey = @"kUserInfoKey";
@implementation UserInfoModel

+ (void)firstLoginSaveUserInfo:(UserInfoModel *)model {
    model.isLogin = YES;
    
    [self saveUserInfo:model];
}


+ (void)saveUserInfo:(UserInfoModel *)model {
    
    NSDictionary *dic = [model yy_modelToJSONObject];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:dic forKey:kUserInfoKey];
    [userDefaults synchronize];
}

+ (UserInfoModel *)getUserInfo {
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSDictionary *dic = [userDefaults objectForKey:kUserInfoKey];
    return [UserInfoModel yy_modelWithDictionary:dic];
}

+ (NSString *)getVerify_auth_token {
    return [NSString stringWithFormat:@"verify_auth_token %@",[self getUserInfo].verify_auth_token];
}


@end
