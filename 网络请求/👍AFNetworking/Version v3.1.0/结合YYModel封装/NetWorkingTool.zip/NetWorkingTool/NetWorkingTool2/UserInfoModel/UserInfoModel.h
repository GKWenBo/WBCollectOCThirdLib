//
//  UserInfoModel.h
//  NetWorkingTool2
//
//  Created by WMB on 2016/12/9.
//  Copyright © 2016年 文波. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserInfoModel : NSObject

@property (nonatomic, copy) NSString *verify_auth_token;/**< 用户权限有限性鉴定的值 */
@property (nonatomic, assign) BOOL isLogin;/**  是否登录  */


/**
 *  仅第一次登陆时调用
 *
 */
+ (void)firstLoginSaveUserInfo:(UserInfoModel *)model;

/**
 *  需要单独修改某个属性或者 置nil时使用
 *
 */
+ (void)saveUserInfo:(UserInfoModel *)model;

/**
 *  更新时使用
 */
+ (void)updateUserInfo:(UserInfoModel *)model;

+ (UserInfoModel *)getUserInfo;

/**
 *  加密用
 */

+ (NSString *)getVerify_auth_token;
@end
