//
//  ViewController.m
//  NetWorkingTool2
//
//  Created by WMB on 2016/12/9.
//  Copyright © 2016年 文波. All rights reserved.
//

#import "ViewController.h"
#import "WebServiceHelper.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [WebService requestGetJsonOperationWithParam:nil action:@"http://c.m.163.com/nc/article/headline/T1348647853363/0-140.html" normalResponse:^(NSInteger status, id data) {
        
        NSLog(@"%ld ------ %@",(long)status,data);
    } exceptionResponse:^(NSError *error) {
        
    }];
}



@end
