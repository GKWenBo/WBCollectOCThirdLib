//
//  AppDelegate.h
//  NetWorkingTool2
//
//  Created by WMB on 2016/12/9.
//  Copyright © 2016年 文波. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

