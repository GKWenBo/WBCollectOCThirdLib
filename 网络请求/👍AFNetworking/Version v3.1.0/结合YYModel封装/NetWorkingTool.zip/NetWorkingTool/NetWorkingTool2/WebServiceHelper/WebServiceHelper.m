//
//  WebServiceHelpler.m
//  NetWorkingTool2
//
//  Created by WMB on 2016/12/9.
//  Copyright © 2016年 文波. All rights reserved.
//

#import "WebServiceHelper.h"
#import "AFNetworkActivityIndicatorManager.h"
#import "UserInfoModel.h"
#import "SVProgressHUD.h"

#ifdef DEBUG
#define kWebService @""
#else

#define kWebService @""

#endif
@implementation WebServiceHelper
#pragma mark -- 创建单例
#pragma mark
+ (WebServiceHelper *)sharedWebServiceHelper {
    static WebServiceHelper *serviceHelper = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        serviceHelper = [[self alloc]init];
    });
    return serviceHelper;
}


#pragma mark -- 配置 AFHTTPSessionManager
#pragma mark
- (AFHTTPSessionManager *)requestOperationManager {
    /** 设置状态栏菊花   */
    [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    AFHTTPSessionManager * manager = [AFHTTPSessionManager manager];
    
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    /**  加密用  */
//    if ([UserInfoModel getUserInfo].isLogin) {
//        [manager.requestSerializer setValue:[UserInfoModel getVerify_auth_token] forHTTPHeaderField:@"Authorization"];
    
//    /**  设置返回数据为json  */
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
//
    manager.requestSerializer.stringEncoding = NSUTF8StringEncoding;
//    /**  设置请求超时时间为10秒  */
//    manager.requestSerializer.timeoutInterval = 10;
        
        
    /**  设置解析格式  */
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithArray:@[@"application/json",
                                                                              @"text/html",
                                                                              @"text/json",
                                                                              @"text/plain",
                                                                              @"text/javascript",
                                                                              @"text/xml",
                                                                              @"image/*"]];
    
    return manager;
}


#pragma mark -- 依次为 GET POST DELETE PUT
#pragma mark
/**
 *  GET请求
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 *
 */
- (void)requestGetJsonOperationWithParam:(NSDictionary *)param
                                  action:(NSString *)action
                          normalResponse:(void(^)(NSInteger status, id data))normalResponse
                       exceptionResponse:(void(^)(NSError *error))exceptionResponse {
    
//    NSString *urlString = [kWebService stringByAppendingFormat:@"/%@?", action];
    
    NSString * urlString = [action stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    AFHTTPSessionManager *manager = [self requestOperationManager];
    [SVProgressHUD show];
    [manager GET:urlString parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [SVProgressHUD dismiss];
        
//        NSError *error = nil;
//        NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
//        if (error) {
//            exceptionResponse(error);
//            return ;
//        }
        
        
        NSLog(@"%@",responseObject);
        normalResponse(0,responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        
        exceptionResponse(error);
        
    } ];

}
/**
 *  Post请求
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 *
 */
- (void)requestPostJsonOperationWithParam:(NSDictionary *)param
                                   action:(NSString *)action
                           normalResponse:(void(^)(NSInteger status, id data))normalResponse
                        exceptionResponse:(void(^)(NSError *error))exceptionResponse {
    NSString *path = [kWebService stringByAppendingPathComponent:action];
    
    AFHTTPSessionManager *manager = [self requestOperationManager];
    [SVProgressHUD show];
    
    [manager POST:path parameters:param progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [SVProgressHUD dismiss];
        
        
        normalResponse(0,responseObject);
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        
        exceptionResponse(error);
        
    }];

}

/**
 *  Delete请求
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 *
 */
- (void)requestDeleteJsonOperationWithParam:(NSDictionary *)param
                                     action:(NSString *)action
                             normalResponse:(void(^)(NSInteger status, id data))normalResponse
                          exceptionResponse:(void(^)(NSError *error))exceptionResponse {
    NSString *path = [kWebService stringByAppendingPathComponent:action];
    
    AFHTTPSessionManager *manager = [self requestOperationManager];
    [SVProgressHUD show];
    
    [manager DELETE:path parameters:param success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [SVProgressHUD dismiss];
        
        normalResponse(0,responseObject);
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        
        exceptionResponse(error);
    }];

}
/**
 *  Put请求
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 *
 */
- (void)requestPutJsonOperationWithParam:(NSDictionary *)param
                                  action:(NSString *)action
                          normalResponse:(void(^)(NSInteger status, id data))normalResponse
                       exceptionResponse:(void(^)(NSError *error))exceptionResponse {
    NSString *path = [kWebService stringByAppendingPathComponent:action];
    
    AFHTTPSessionManager *manager = [self requestOperationManager];
    [SVProgressHUD show];
    
    [manager PUT:path parameters:param success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [SVProgressHUD dismiss];
        
        normalResponse(0,responseObject);
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
        
        exceptionResponse(error);
        
    }];

}

#pragma mark -- 返回为Model对象
#pragma mark
/**
 *  GET请求将请求数据转换为模型对象
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param modelClass        传入的模型对象
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 */
- (void)requestGetJsonModelWithParam:(NSDictionary *)param
                              action:(NSString *)action
                          modelClass:(Class)modelClass
                      normalResponse:(void(^)(NSInteger status, id data, NSObject *model))normalResponse
                   exceptionResponse:(void(^)(NSError *error))exceptionResponse {
    [SVProgressHUD show];
    
    [self requestGetJsonOperationWithParam:param
                                    action:action
                            normalResponse:^(NSInteger status, id data) {
//                                [SVProgressHUD dismiss];
                                
                                if ([data isKindOfClass:[NSDictionary class]]) {
                                    normalResponse(status, data, [modelClass yy_modelWithDictionary:data]);
                                } else {
                                    exceptionResponse([NSError errorWithDomain:@""
                                                                          code:0
                                                                      userInfo:@{@"data": @"服务器数据为空！"}]);
                                }
                            } exceptionResponse:^(NSError *error) {
                                [SVProgressHUD dismiss];
                                
                                exceptionResponse(error);
                            }];

}
/**
 *  GET请求将请求数组转换为模型
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param modelClass        传入的模型对象
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 */
- (void)requestGetJsonArrayWithParam:(NSDictionary *)param
                              action:(NSString *)action
                          modelClass:(Class)modelClass
                      normalResponse:(void(^)(NSInteger status, id data, NSMutableArray *array))normalResponse
                   exceptionResponse:(void(^)(NSError *error))exceptionResponse {
    [SVProgressHUD show];
    
    [self requestGetJsonOperationWithParam:param
                                    action:action
                            normalResponse:^(NSInteger status, id data) {
                                [SVProgressHUD dismiss];
                                
                                if ([data isKindOfClass:[NSArray class]]) {
                                    NSMutableArray *returnArr = [NSMutableArray array];
                                    
                                    if (modelClass == [NSString class]) {
                                        for (id dic in data) {
                                            [returnArr addObject:dic];
                                        }
                                        normalResponse(status, data, returnArr);
                                    } else {
                                        for (id dic in data) {
                                            
                                            [returnArr addObject:[modelClass yy_modelWithDictionary:dic]];
                                        }
                                        normalResponse(status, data, returnArr);
                                    }
                                    
                                } else {
                                    normalResponse(status, data, [@[] mutableCopy]);
                                }
                                
                            } exceptionResponse:^(NSError *error) {
                                [SVProgressHUD dismiss];
                                
                                exceptionResponse(error);
                            }];
}
/**
 *  POST请求将模型对象上传到服务器
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param modelClass        传入的模型对象
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 */
- (void)requestPostJsonModelWithParam:(NSDictionary *)param
                               action:(NSString *)action
                           modelClass:(Class)modelClass
                       normalResponse:(void(^)(NSInteger status, id data, NSObject *model))normalResponse
                    exceptionResponse:(void(^)(NSError *error))exceptionResponse {
    [SVProgressHUD show];
    
    [self requestPostJsonOperationWithParam:param
                                     action:action
                             normalResponse:^(NSInteger status, id data) {
                                 [SVProgressHUD dismiss];
                                 
                                 if ([data isKindOfClass:[NSDictionary class]]) {
                                     normalResponse(status, data, [modelClass yy_modelWithDictionary:data]);
                                 } else {
                                     exceptionResponse([NSError errorWithDomain:@""
                                                                           code:0
                                                                       userInfo:@{@"data": @"服务器数据为空！"}]);
                                 }
                                 
                             } exceptionResponse:^(NSError *error) {
                                 [SVProgressHUD dismiss];
                                 
                                 exceptionResponse(error);
                             }];
}
/**
 *  POST请求将数组模型对象上传到服务器
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param modelClass        传入的模型对象
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 */
- (void)requestPostJsonArrayWithParam:(NSDictionary *)param
                               action:(NSString *)action
                           modelClass:(Class)modelClass
                       normalResponse:(void(^)(NSInteger status, id data, NSMutableArray *array))normalResponse
                    exceptionResponse:(void(^)(NSError *error))exceptionResponse {
    [SVProgressHUD show];
    [self requestPostJsonOperationWithParam:param
                                     action:action
                             normalResponse:^(NSInteger status, id data) {
                                 [SVProgressHUD dismiss];
                                 
                                 if ([data isKindOfClass:[NSArray class]]) {
                                     NSMutableArray *returnArr = [NSMutableArray array];
                                     
                                     if (modelClass == [NSString class]) {
                                         for (id dic in data) {
                                             [returnArr addObject:dic];
                                         }
                                         normalResponse(status, data, returnArr);
                                     } else {
                                         for (id dic in data) {
                                             [returnArr addObject:[modelClass yy_modelWithDictionary:dic]];
                                         }
                                         normalResponse(status, data, returnArr);
                                     }
                                     
                                 } else {
                                     normalResponse(status, data, [@[] mutableCopy]);
                                 }
                                 
                             } exceptionResponse:^(NSError *error) {
                                 [SVProgressHUD dismiss];
                                 
                                 exceptionResponse(error);
                             }];
}

@end
