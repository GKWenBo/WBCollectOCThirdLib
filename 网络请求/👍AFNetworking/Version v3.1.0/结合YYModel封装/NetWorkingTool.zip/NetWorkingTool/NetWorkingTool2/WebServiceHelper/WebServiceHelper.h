//
//  WebServiceHelpler.h
//  NetWorkingTool2
//
//  Created by WMB on 2016/12/9.
//  Copyright © 2016年 文波. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+YYModel.h"
#import <AFNetworking.h>
/**
 *  请求状态
 */
typedef NS_ENUM(NSInteger, RequestStatusType) {
    /**
     *  成功
     */
    RequestStatusTypeSuccess = 90000,
    /**
     *  请求失败
     */
    RequestStatusTypeFailed = 99999,
    /**
     *  系统未知错误
     */
    RequestStatusTypeSystemError = 50000,    
};

#define WebService [WebServiceHelper sharedWebServiceHelper]

@interface WebServiceHelper : NSObject

/**
 *  初始化
 *
 *  @return return value description
 */
+ (WebServiceHelper *)sharedWebServiceHelper;


#pragma mark -- 依次为 GET POST DELETE PUT
#pragma mark
/**
 *  GET请求
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 *
 */
- (void)requestGetJsonOperationWithParam:(NSDictionary *)param
                                  action:(NSString *)action
                          normalResponse:(void(^)(NSInteger status, id data))normalResponse
                       exceptionResponse:(void(^)(NSError *error))exceptionResponse;
/**
 *  Post请求
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 *
 */
- (void)requestPostJsonOperationWithParam:(NSDictionary *)param
                                   action:(NSString *)action
                           normalResponse:(void(^)(NSInteger status, id data))normalResponse
                        exceptionResponse:(void(^)(NSError *error))exceptionResponse;

/**
 *  Delete请求
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 *
 */
- (void)requestDeleteJsonOperationWithParam:(NSDictionary *)param
                                     action:(NSString *)action
                             normalResponse:(void(^)(NSInteger status, id data))normalResponse
                          exceptionResponse:(void(^)(NSError *error))exceptionResponse;
/**
 *  Put请求
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 *
 */
- (void)requestPutJsonOperationWithParam:(NSDictionary *)param
                                  action:(NSString *)action
                          normalResponse:(void(^)(NSInteger status, id data))normalResponse
                       exceptionResponse:(void(^)(NSError *error))exceptionResponse;

#pragma mark -- 返回为Model对象
#pragma mark
/**
 *  GET请求将请求数据转换为模型对象
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param modelClass        传入的模型对象
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 */
- (void)requestGetJsonModelWithParam:(NSDictionary *)param
                              action:(NSString *)action
                          modelClass:(Class)modelClass
                      normalResponse:(void(^)(NSInteger status, id data, NSObject *model))normalResponse
                   exceptionResponse:(void(^)(NSError *error))exceptionResponse;
/**
 *  GET请求将请求数组转换为模型
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param modelClass        传入的模型对象
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 */
- (void)requestGetJsonArrayWithParam:(NSDictionary *)param
                              action:(NSString *)action
                          modelClass:(Class)modelClass
                      normalResponse:(void(^)(NSInteger status, id data, NSMutableArray *array))normalResponse
                   exceptionResponse:(void(^)(NSError *error))exceptionResponse;
/**
 *  POST请求将模型对象上传到服务器
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param modelClass        传入的模型对象
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 */
- (void)requestPostJsonModelWithParam:(NSDictionary *)param
                               action:(NSString *)action
                           modelClass:(Class)modelClass
                       normalResponse:(void(^)(NSInteger status, id data, NSObject *model))normalResponse
                    exceptionResponse:(void(^)(NSError *error))exceptionResponse;
/**
 *  POST请求将数组模型对象上传到服务器
 *
 *  @param param             参数 NSDictionary
 *  @param action            接口方法名
 *  @param modelClass        传入的模型对象
 *  @param normalResponse    常规block
 *  @param exceptionResponse 异常block
 */
- (void)requestPostJsonArrayWithParam:(NSDictionary *)param
                               action:(NSString *)action
                           modelClass:(Class)modelClass
                       normalResponse:(void(^)(NSInteger status, id data, NSMutableArray *array))normalResponse
                    exceptionResponse:(void(^)(NSError *error))exceptionResponse;

@end
