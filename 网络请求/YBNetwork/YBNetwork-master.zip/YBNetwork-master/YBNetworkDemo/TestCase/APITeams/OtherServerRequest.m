//
//  OtherRequest.m
//  YBNetworkDemo
//
//  Created by 波儿菜 on 2019/4/9.
//  Copyright © 2019 波儿菜. All rights reserved.
//

#import "OtherServerRequest.h"

@implementation OtherServerRequest
//TODO
@end
