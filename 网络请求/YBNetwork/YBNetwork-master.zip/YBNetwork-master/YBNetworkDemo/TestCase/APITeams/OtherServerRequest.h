//
//  OtherRequest.h
//  YBNetworkDemo
//
//  Created by 波儿菜 on 2019/4/9.
//  Copyright © 2019 波儿菜. All rights reserved.
//

#import "YBBaseRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface OtherServerRequest : YBBaseRequest

@end

NS_ASSUME_NONNULL_END
