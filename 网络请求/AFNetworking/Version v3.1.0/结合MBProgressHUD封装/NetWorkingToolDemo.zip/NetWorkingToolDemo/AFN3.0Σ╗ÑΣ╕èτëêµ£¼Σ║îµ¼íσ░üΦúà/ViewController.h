//
//  ViewController.h
//  AFN3.0以上版本二次封装
//
//  Created by WMB on 2016/11/4.
//  Copyright © 2016年 WMB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

