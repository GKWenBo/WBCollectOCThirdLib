//
//  ViewController.m
//  AFN3.0以上版本二次封装
//
//  Created by WMB on 2016/11/4.
//  Copyright © 2016年 WMB. All rights reserved.
//

#import "ViewController.h"
#import "MBProgressHUD.h"

#import "NetWorkingTool.h"
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UILabel *progressLabel;
@property (nonatomic,strong) NetWorkURLSessionTask * task;


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].windows.lastObject.rootViewController.view animated:YES];
    
    
    
}

- (IBAction)start:(id)sender {
    NSString *path=[NSHomeDirectory() stringByAppendingString:[NSString stringWithFormat:@"/Documents/image.jpg"]];

    
    _task = [NetWorkingTool downloadWithUrl:@"http://www.aomy.com/attach/2012-09/1347583576vgC6.jpg" saveToPath:path progress:^(int64_t bytesProgress, int64_t totalBytesProgress) {
        //封装方法里已经回到主线程，所有这里不用再调主线程了
        _progressLabel.text = [NSString stringWithFormat:@"进度==%.2f",1.0 * bytesProgress/ totalBytesProgress];
    } success:^(id response) {
        NSLog(@"---------%@",response);
        _progressLabel.text=@"下载完成";
        
    } failed:^(NSError *error) {
        
    } showHUD:NO];

//    _task = [NetWorkingTool getWithUrl:@"http://c.m.163.com/nc/article/headline/T1348647853363/0-140.html" parameters:nil success:^(id response) {
//        
//    } failed:^(NSError *error) {
//        NSLog(@"failed");
//    } showHUD:YES];
    
}
- (IBAction)puse:(id)sender {
     [_task suspend];
    
}
- (IBAction)continue:(id)sender {
     [_task resume];
}



@end
