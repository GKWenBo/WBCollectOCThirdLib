//
//  WBNetWorkTool.m
//  WBNetWorkToolDemo
//
//  Created by WMB on 2017/11/12.
//  Copyright © 2017年 WMB. All rights reserved.
//

#import "WBNetWorkTool.h"

/** << 请求服务器基地址 > */
#ifdef DEBUG
NSString *const kWBBaseRequestUrl = @"";
#else
NSString *const kWBBaseRequestUrl = @"";
#endif
/** << 请求状态码key > */
NSString *const kWBResponseStatusCodeKey = @"status";
/** << 请求数据总分页数key > */
NSString *const kWBResponseTotalPageKey = @"total_page";
/** << 服务器返回状态信息key > */
NSString *const kWBResponseMsgKey = @"resMsg";
NSString *const kWBResponseDataKey = @"data";

@interface WBNetWorkTool ()

@property (nonatomic, strong) AFHTTPSessionManager *manager;

@end

@implementation WBNetWorkTool

+ (instancetype)shareNetWorkTool {
    static WBNetWorkTool *netWorkTool = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!netWorkTool) {
            netWorkTool = [[self alloc]init];
        }
    });
    return netWorkTool;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.manager = [AFHTTPSessionManager manager];
        /** << 请求超时设置 > */
        self.manager.requestSerializer.timeoutInterval = self.timeoutInterval > 0 ? self.timeoutInterval : 20;
        /** << 响应不使用AFN默认转换,保持原有数据 > */
        self.manager.responseSerializer = [AFHTTPResponseSerializer serializer];
        /** << 请求不使用AFN默认转换,保持原有数据 > */
        self.manager.requestSerializer = [AFHTTPRequestSerializer serializer];
        self.manager.requestSerializer.stringEncoding = NSUTF8StringEncoding;
        /** << 设置解析格式 > */
        self.manager.responseSerializer.acceptableContentTypes = [NSSet setWithArray:@[@"application/json",
                                                                                   @"text/html",
                                                                                   @"text/json",
                                                                                   @"text/plain",
                                                                                   @"text/javascript",
                                                                                   @"text/xml",
                                                                                   @"image/*"]];
    }
    return self;
}

#pragma mark ------ < Private Method > ------
#pragma mark
- (void)wb_settingRequestSerializerHTTPHeaderField {
    [self.manager.requestSerializer setValue:@"" forHTTPHeaderField:@"Authorization"];
}

#pragma mark ------ < Base Request Method > ------
#pragma mark
/**
 GET请求 返回NSURLSessionDataTask方便管理
 
 @param urlString   接口地址
 @param parameters  请求参数
 @param completed   请求成功回调
 @param failure     请求失败回调
 @return            NSURLSessionDataTask
 */
- (NSURLSessionDataTask *)wb_startGETRequestWithUrlString:(NSString *)urlString
                                               parameters:(NSDictionary *)parameters
                                                completed:(WBReponseCompletedBlock)completed
                                                  failure:(WBResponseFailureBlock)failure {
    /** << 拼接基地址 > */
    NSString *url = [kWBBaseRequestUrl stringByAppendingPathComponent:urlString];
    /** << 设置请求header > */
    [self wb_settingRequestSerializerHTTPHeaderField];
    NSURLSessionDataTask *dataTask = [self.manager GET:url parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        /** << 数据解析 > */
        NSError *error = nil;
        NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        /** << 解析出错 > */
        if (error) {
            failure(error);
            return ;
        }
        /** << 状态码判断 > */
        if ([dataDict valueForKey:kWBResponseStatusCodeKey]) {
            NSInteger status = [[dataDict valueForKey:kWBResponseStatusCodeKey] integerValue];
            if (status == WBResponseStatusSuccessCode) {
                NSInteger totalPage = 0;
                if ([dataDict valueForKey:kWBResponseTotalPageKey]) {
                    totalPage = [[dataDict valueForKey:kWBResponseTotalPageKey] integerValue];
                }
                completed(status,[dataDict valueForKey:kWBResponseDataKey],totalPage);
            }else if (status == WBResponseStatusAuthenticationFailedCode) {
                /** << 鉴权失败或token过期处理 > */
            }else {
                error = [NSError errorWithDomain:@"" code:0 userInfo:dataDict];
                failure(error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    return dataTask;
}

- (NSURLSessionDataTask *)wb_startPOSTRequestWithUrlString:(NSString *)urlString
                                                parameters:(NSDictionary *)parameters
                                                 completed:(WBReponseCompletedBlock)completed
                                                   failure:(WBResponseFailureBlock)failure {
    NSString *url = [kWBBaseRequestUrl stringByAppendingPathComponent:urlString];
    [self wb_settingRequestSerializerHTTPHeaderField];
    NSURLSessionDataTask *dataTask = [self.manager POST:url parameters:parameters progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSError *error = nil;
        NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        if (error) {
            failure(error);
            return ;
        }
        if ([dataDict valueForKey:kWBResponseStatusCodeKey]) {
            NSInteger status = [[dataDict valueForKey:kWBResponseStatusCodeKey] integerValue];
            if (status == WBResponseStatusSuccessCode) {
                NSInteger totalPage = 0;
                if ([dataDict valueForKey:kWBResponseTotalPageKey]) {
                    totalPage = [[dataDict valueForKey:kWBResponseTotalPageKey] integerValue];
                }
                completed(status,[dataDict valueForKey:kWBResponseDataKey],totalPage);
            }else if (status == WBResponseStatusAuthenticationFailedCode) {
                /** << 鉴权失败或token过期处理 > */
            }else {
                error = [NSError errorWithDomain:@"" code:0 userInfo:dataDict];
                failure(error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    return dataTask;
}

- (NSURLSessionDataTask *)wb_startDELETERequestWithUrlString:(NSString *)urlString
                                                  parameters:(NSDictionary *)parameters
                                                   completed:(WBReponseCompletedBlock)completed
                                                     failure:(WBResponseFailureBlock)failure {
    NSString *url = [kWBBaseRequestUrl stringByAppendingPathComponent:urlString];
    [self wb_settingRequestSerializerHTTPHeaderField];
    NSURLSessionDataTask *dataTask = [self.manager DELETE:url parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSError *error = nil;
        NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        if (error) {
            failure(error);
            return ;
        }
        if ([dataDict valueForKey:kWBResponseStatusCodeKey]) {
            NSInteger status = [[dataDict valueForKey:kWBResponseStatusCodeKey] integerValue];
            if (status == WBResponseStatusSuccessCode) {
                NSInteger totalPage = 0;
                if ([dataDict valueForKey:kWBResponseTotalPageKey]) {
                    totalPage = [[dataDict valueForKey:kWBResponseTotalPageKey] integerValue];
                }
                completed(status,[dataDict valueForKey:kWBResponseDataKey],totalPage);
            }else if (status == WBResponseStatusAuthenticationFailedCode) {
                /** << 鉴权失败或token过期处理 > */
            }else {
                error = [NSError errorWithDomain:@"" code:0 userInfo:dataDict];
                failure(error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    return dataTask;
}

- (NSURLSessionDataTask *)wb_startPUTRequestWithUrlString:(NSString *)urlString
                                               parameters:(NSDictionary *)parameters
                                                completed:(WBReponseCompletedBlock)completed
                                                  failure:(WBResponseFailureBlock)failure {
    NSString *url = [kWBBaseRequestUrl stringByAppendingPathComponent:urlString];
    [self wb_settingRequestSerializerHTTPHeaderField];
    NSURLSessionDataTask *dataTask = [self.manager PUT:url parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSError *error = nil;
        NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        if (error) {
            failure(error);
            return ;
        }
        if ([dataDict valueForKey:kWBResponseStatusCodeKey]) {
            NSInteger status = [[dataDict valueForKey:kWBResponseStatusCodeKey] integerValue];
            if (status == WBResponseStatusSuccessCode) {
                NSInteger totalPage = 0;
                if ([dataDict valueForKey:kWBResponseTotalPageKey]) {
                    totalPage = [[dataDict valueForKey:kWBResponseTotalPageKey] integerValue];
                }
                completed(status,[dataDict valueForKey:kWBResponseDataKey],totalPage);
            }else if (status == WBResponseStatusAuthenticationFailedCode) {
                /** << 鉴权失败或token过期处理 > */
            }else {
                error = [NSError errorWithDomain:@"" code:0 userInfo:dataDict];
                failure(error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    return dataTask;
}

- (NSURLSessionDataTask *)wb_startPATCHRequestWithUrlString:(NSString *)urlString
                                                 parameters:(NSDictionary *)parameters
                                                  completed:(WBReponseCompletedBlock)completed
                                                    failure:(WBResponseFailureBlock)failure {
    NSString *url = [kWBBaseRequestUrl stringByAppendingPathComponent:urlString];
    [self wb_settingRequestSerializerHTTPHeaderField];
    NSURLSessionDataTask *dataTask = [self.manager PATCH:url parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSError *error = nil;
        NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        if (error) {
            failure(error);
            return ;
        }
        if ([dataDict valueForKey:kWBResponseStatusCodeKey]) {
            NSInteger status = [[dataDict valueForKey:kWBResponseStatusCodeKey] integerValue];
            if (status == WBResponseStatusSuccessCode) {
                NSInteger totalPage = 0;
                if ([dataDict valueForKey:kWBResponseTotalPageKey]) {
                    totalPage = [[dataDict valueForKey:kWBResponseTotalPageKey] integerValue];
                }
                completed(status,[dataDict valueForKey:kWBResponseDataKey],totalPage);
            }else if (status == WBResponseStatusAuthenticationFailedCode) {
                /** << 鉴权失败或token过期处理 > */
            }else {
                error = [NSError errorWithDomain:@"" code:0 userInfo:dataDict];
                failure(error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    return dataTask;
}

#pragma mark ------ < Return Model Request Method > ------
#pragma mark
- (NSURLSessionDataTask *)wb_startGETRequestModelWithUrlString:(NSString *)urlString
                                                    parameters:(NSDictionary *)parameters
                                                    modelClass:(Class)modelClass
                                                     completed:(WBResponseConvertToModelBlock)completed
                                                       failure:(WBResponseFailureBlock)failure {
    NSURLSessionDataTask *dataTask = [self wb_startGETRequestWithUrlString:urlString parameters:parameters completed:^(NSInteger status, id responseObject, NSInteger totalPage) {
        if ([responseObject isKindOfClass:[NSDictionary class]]) {
            /** << 字典转模型 > */
            completed(status,responseObject,[modelClass mj_objectWithKeyValues:responseObject],totalPage);
        }else {
            NSError *error = [NSError errorWithDomain:@"" code:0 userInfo:@{kWBResponseDataKey:@"服务器数据为空或格式不匹配"}];
            failure(error);
        }
    } failure:^(NSError *error) {
        failure(error);
    }];
    return dataTask;
}

- (NSURLSessionDataTask *)wb_startGETRequestModelArrayWithUrlString:(NSString *)urlString
                                                         parameters:(NSDictionary *)parameters
                                                         modelClass:(Class)modelClass
                                                          completed:(WBResponseConvertToModelArrayBlock)completed
                                                            failure:(WBResponseFailureBlock)failure {
    NSURLSessionDataTask *dataTask = [self wb_startGETRequestWithUrlString:urlString parameters:parameters completed:^(NSInteger status, id responseObject, NSInteger totalPage) {
        if ([responseObject isKindOfClass:[NSArray class]]) {
            /** << 字典数组转成模型数组 > */
            NSArray *dataArray = [modelClass mj_objectArrayWithKeyValuesArray:responseObject];
            completed(status,responseObject,dataArray,totalPage);
        }else {
            completed(status,responseObject,@[].copy,totalPage);
        }
    } failure:^(NSError *error) {
        failure(error);
    }];
    return dataTask;
}

- (NSURLSessionDataTask *)wb_startPOSTRequestModelWithUrlString:(NSString *)urlString
                                                     parameters:(NSDictionary *)parameters
                                                     modelClass:(Class)modelClass
                                                      completed:(WBResponseConvertToModelBlock)completed
                                                        failure:(WBResponseFailureBlock)failure {
    NSURLSessionDataTask *dataTask = [self wb_startPOSTRequestWithUrlString:urlString parameters:parameters completed:^(NSInteger status, id responseObject, NSInteger totalPage) {
        if ([responseObject isKindOfClass:[NSDictionary class]]) {
            /** << 字典转模型 > */
            completed(status,responseObject,[modelClass mj_objectWithKeyValues:responseObject],totalPage);
        }else {
            NSError *error = [NSError errorWithDomain:@"" code:0 userInfo:@{kWBResponseDataKey:@"服务器数据为空或格式不匹配"}];
            failure(error);
        }
    } failure:^(NSError *error) {
        failure(error);
    }];
    return dataTask;
}

- (NSURLSessionDataTask *)wb_startPOSTRequestModelArrayWithUrlString:(NSString *)urlString
                                                          parameters:(NSDictionary *)parameters
                                                          modelClass:(Class)modelClass
                                                           completed:(WBResponseConvertToModelArrayBlock)completed
                                                             failure:(WBResponseFailureBlock)failure {
    NSURLSessionDataTask *dataTask = [self wb_startPOSTRequestWithUrlString:urlString parameters:parameters completed:^(NSInteger status, id responseObject, NSInteger totalPage) {
        if ([responseObject isKindOfClass:[NSArray class]]) {
            /** << 字典数组转成模型数组 > */
            NSArray *dataArray = [modelClass mj_objectArrayWithKeyValuesArray:responseObject];
            completed(status,responseObject,dataArray,totalPage);
        }else {
            completed(status,responseObject,@[].copy,totalPage);
        }
    } failure:^(NSError *error) {
        failure(error);
    }];
    return dataTask;
}

#pragma mark ------ < 上传图片 > ------
#pragma mark
- (NSURLSessionDataTask *)wb_uploadImagesWithUrlString:(NSString *)urlString
                                            parameters:(NSDictionary *)parameters
                                            imageArray:(NSArray *)imageArray
                                                  name:(NSString *)name
                                              progress:(WBUploadProgress)progress
                                             completed:(WBReponseCompletedBlock)completed
                                               failure:(WBResponseFailureBlock)failure; {
    NSString *url = [kWBBaseRequestUrl stringByAppendingPathComponent:urlString];
    [self wb_settingRequestSerializerHTTPHeaderField];
    NSURLSessionDataTask *dataTask = [self.manager POST:url parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        [imageArray enumerateObjectsUsingBlock:^(UIImage *image, NSUInteger idx, BOOL * _Nonnull stop) {
            /**  < 压缩图片然后再上传(1.0代表无损 0~~1.0区间) >  */
            NSData *imageData = UIImageJPEGRepresentation(image, 1.f);
            /**  < 创建文件名 >  */
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
            dateFormatter.dateFormat = @"yyyyMMddHHmmss";
            NSString *dateString = [dateFormatter stringFromDate:[NSDate date]];
            NSString *fileName = [dateString stringByAppendingFormat:@"%@%lu.jpg",dateString,idx];
            [formData appendPartWithFileData:imageData name:name fileName:fileName mimeType:@"image/jpeg"];
        }];
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        if (progress) {
            progress(uploadProgress.completedUnitCount,uploadProgress.totalUnitCount);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        /** << 数据解析 > */
        NSError *error = nil;
        NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        /** << 解析出错 > */
        if (error) {
            failure(error);
            return ;
        }
        /** << 状态码判断 > */
        if ([dataDict valueForKey:kWBResponseStatusCodeKey]) {
            NSInteger status = [[dataDict valueForKey:kWBResponseStatusCodeKey] integerValue];
            if (status == WBResponseStatusSuccessCode) {
                NSInteger totalPage = 0;
                if ([dataDict valueForKey:kWBResponseTotalPageKey]) {
                    totalPage = [[dataDict valueForKey:kWBResponseTotalPageKey] integerValue];
                }
                completed(status,[dataDict valueForKey:kWBResponseDataKey],totalPage);
            }else if (status == WBResponseStatusAuthenticationFailedCode) {
                /** << 鉴权失败或token过期处理 > */
            }else {
                error = [NSError errorWithDomain:@"" code:0 userInfo:dataDict];
                failure(error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    return dataTask;
}

- (NSURLSessionDataTask *)wb_uploadImagesWithUrlString:(NSString *)urlString
                                            parameters:(NSDictionary *)parameters
                                                 image:(NSArray *)image
                                                  name:(NSString *)name
                                              progress:(WBUploadProgress)progress
                                             completed:(WBReponseCompletedBlock)completed
                                               failure:(WBResponseFailureBlock)failure {
    return [self wb_uploadImagesWithUrlString:urlString parameters:parameters imageArray:@[image] name:name progress:progress completed:completed failure:failure];
}

- (NSURLSessionDataTask *)wb_uploadImagesWithUrlString:(NSString *)urlString
                                            parameters:(NSDictionary *)parameters
                                         imageUrlArray:(NSArray *)imageUrlArray
                                                  name:(NSString *)name
                                              progress:(WBUploadProgress)progress
                                             completed:(WBReponseCompletedBlock)completed
                                               failure:(WBResponseFailureBlock)failure {
    NSString *url = [kWBBaseRequestUrl stringByAppendingPathComponent:urlString];
    [self wb_settingRequestSerializerHTTPHeaderField];
    NSURLSessionDataTask *dataTask = [self.manager POST:url parameters:parameters constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        [imageUrlArray enumerateObjectsUsingBlock:^(NSString *pathUrl, NSUInteger idx, BOOL * _Nonnull stop) {
            /**  < 根据本地路径获取url(相册等资源上传) >  */
            /**  <  [NSURL URLWithString:picModle.url] 可以换成网络的图片在上传 >  */
            NSURL *imageUrl = [NSURL fileURLWithPath:pathUrl];
            /**  < 创建文件名 >  */
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
            dateFormatter.dateFormat = @"yyyyMMddHHmmss";
            NSString *dateString = [dateFormatter stringFromDate:[NSDate date]];
            NSString *fileName = [dateString stringByAppendingFormat:@"%@%lu.jpg",dateString,idx];
            
            [formData appendPartWithFileURL:imageUrl name:name fileName:fileName mimeType:@"application/octet-stream" error:nil];
        }];
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        if (progress) {
            progress(uploadProgress.completedUnitCount,uploadProgress.totalUnitCount);
        }
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        /** << 数据解析 > */
        NSError *error = nil;
        NSDictionary *dataDict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingAllowFragments error:&error];
        /** << 解析出错 > */
        if (error) {
            failure(error);
            return ;
        }
        /** << 状态码判断 > */
        if ([dataDict valueForKey:kWBResponseStatusCodeKey]) {
            NSInteger status = [[dataDict valueForKey:kWBResponseStatusCodeKey] integerValue];
            if (status == WBResponseStatusSuccessCode) {
                NSInteger totalPage = 0;
                if ([dataDict valueForKey:kWBResponseTotalPageKey]) {
                    totalPage = [[dataDict valueForKey:kWBResponseTotalPageKey] integerValue];
                }
                completed(status,[dataDict valueForKey:kWBResponseDataKey],totalPage);
            }else if (status == WBResponseStatusAuthenticationFailedCode) {
                /** << 鉴权失败或token过期处理 > */
            }else {
                error = [NSError errorWithDomain:@"" code:0 userInfo:dataDict];
                failure(error);
            }
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        failure(error);
    }];
    return dataTask;
}

- (NSURLSessionDataTask *)wb_uploadImagesWithUrlString:(NSString *)urlString
                                            parameters:(NSDictionary *)parameters
                                              imageUrl:(NSArray *)imageUrl
                                                  name:(NSString *)name
                                              progress:(WBUploadProgress)progress
                                             completed:(WBReponseCompletedBlock)completed
                                               failure:(WBResponseFailureBlock)failure {
    return [self wb_uploadImagesWithUrlString:urlString parameters:parameters imageUrl:@[imageUrl] name:name progress:progress completed:completed failure:failure];
}

#pragma mark ------ < 下载文件 > ------
#pragma mark
- (NSURLSessionDownloadTask *)wb_downloadWithUrl:(NSString *)url
                                    saveFilePath:(NSString *)saveFilePath
                                        progress:(WBDownloadProgress)progress
                                       completed:(WBDownloadResponseBlock)completed
                                         failure:(WBResponseFailureBlock)failure {
    NSString *urlString = [kWBBaseRequestUrl stringByAppendingPathComponent:url];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]];
    [self wb_settingRequestSerializerHTTPHeaderField];
    NSURLSessionDownloadTask *downloadTask = [self.manager downloadTaskWithRequest:request progress:^(NSProgress * _Nonnull downloadProgress) {
        /**  < 进度回调 >  */
        if (progress) {
            progress(downloadProgress.completedUnitCount,downloadProgress.totalUnitCount);
        }
    } destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
        /**  < 保存的路径 >  */
        return [NSURL URLWithString:saveFilePath];
    } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
        if (error == nil) {
            if (completed) {
                completed(filePath.absoluteString);
            }
        }else {
            failure(error);
        }
    }];
    /**  < 开启下载任务 >  */
    [downloadTask resume];
    return downloadTask;
}

#pragma mark ------ < 网络状态监测 > ------
#pragma mark
/**
 Start monitoring network status
 */
- (void)wb_startMonitoring {
    /** << 获得网络监控的管理者 > */
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    /** << 设置网络状态改变后的处理 > */
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                NSLog(@"未知网络");
                [WBNetWorkTool shareNetWorkTool].netWorkStatus = WBNetWorkReachabilityStatusUnknown;
                break;
            case AFNetworkReachabilityStatusNotReachable:
                NSLog(@"没有网络");
                [WBNetWorkTool shareNetWorkTool].netWorkStatus = WBNetWorkReachabilityStatusNotReachable;
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
                NSLog(@"移动网络");
                [WBNetWorkTool shareNetWorkTool].netWorkStatus = WBNetWorkReachabilityStatusViaWWAN;
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                NSLog(@"wifi");
                [WBNetWorkTool shareNetWorkTool].netWorkStatus = WBNetWorkReachabilityStatusViaWiFi;
                break;
            default:
                break;
        }
    }];
}

#pragma mark ------ < Cancle Request > ------
#pragma mark
- (void)wb_cancleRequestWithUrlString:(NSString *)urlString {
    [self.manager.session getTasksWithCompletionHandler:^(NSArray<NSURLSessionDataTask *> * _Nonnull dataTasks, NSArray<NSURLSessionUploadTask *> * _Nonnull uploadTasks, NSArray<NSURLSessionDownloadTask *> * _Nonnull downloadTasks) {
        for (NSURLSessionTask *task in dataTasks) {
            if ([task.currentRequest.URL.absoluteString containsString:urlString]) {
                [task cancel];
            }
        }
    }];
}

- (void)wb_cancleAllRequest {
    [self.manager.session getTasksWithCompletionHandler:^(NSArray<NSURLSessionDataTask *> * _Nonnull dataTasks, NSArray<NSURLSessionUploadTask *> * _Nonnull uploadTasks, NSArray<NSURLSessionDownloadTask *> * _Nonnull downloadTasks) {
        for (NSURLSessionTask *task in dataTasks) {
            [task cancel];
        }
    }];
}

@end
