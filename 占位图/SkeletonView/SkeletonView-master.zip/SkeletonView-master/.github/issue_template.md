⚠️ Please fill out this template when filing an issue.

#### 🙏🏼 *Please check if it already exists other issue related with yours.*

### What did you do?

*Please replace this with what you did.*

### What did you expect to happen?

*Please replace this with what you expected to happen.*

### What happened instead?

*Please replace this with of what happened instead.*  

### Steps to reproduce the behavior

*Please replace this with the steps to reproduce the behavior.*

### SkeletonView Environment

**SkeletonView version:**
**Xcode version:**
**Swift version:**
