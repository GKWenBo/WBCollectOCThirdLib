//
//  TableViewSkeletonController.h
//  SomoDemo
//
//  Created by 向小辉 on 2017/11/25.
//  Copyright © 2017年 KINX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewSkeletonController : UITableViewController

@end
