//
//  MainViewController.h
//  Applications
//
//  Created by Ignacio on 6/6/14.
//  Copyright (c) 2014 DZN Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailViewController.h"
#import "Application.h"

@interface MainViewController : UITableViewController

@end
