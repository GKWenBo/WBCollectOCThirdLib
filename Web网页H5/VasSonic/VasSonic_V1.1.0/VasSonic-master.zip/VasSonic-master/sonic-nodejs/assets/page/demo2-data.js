
let dataFn = function(ctx){
	return {urlParams: ctx.request.query};
};
module.exports = dataFn; 