//
//  AspectsAppDelegate.h
//  AspectsDemoOSX
//
//  Created by Ash Furrow on 2014-05-05.
//  Copyright (c) 2014 PSPDFKit GmbH. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AspectsAppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
