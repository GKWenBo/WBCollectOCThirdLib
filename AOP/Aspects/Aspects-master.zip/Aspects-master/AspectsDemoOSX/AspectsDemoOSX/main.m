//
//  main.m
//  AspectsDemoOSX
//
//  Created by Ash Furrow on 2014-05-05.
//  Copyright (c) 2014 PSPDFKit GmbH. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
