//
//  AspectsViewController.h
//  AspectsDemo
//
//  Created by Peter Steinberger on 05/05/14.
//  Copyright (c) 2014 PSPDFKit GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AspectsViewController : UIViewController

- (IBAction)buttonPressed:(id)sender;

@end
