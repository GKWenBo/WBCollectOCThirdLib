//
//  DemoDanmakuCell.h
//  HJDanmakuDemo
//
//  Created by haijiao on 2017/7/14.
//  Copyright © 2017年 olinone. All rights reserved.
//

#import "HJDanmakuCell.h"

@interface DemoDanmakuCell : HJDanmakuCell

@end
