//
//  AppDelegate.h
//  BarrageRendererDemo
//
//  Created by UnAsh on 15/7/15.
//  Copyright (c) 2015年 ExBye Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

