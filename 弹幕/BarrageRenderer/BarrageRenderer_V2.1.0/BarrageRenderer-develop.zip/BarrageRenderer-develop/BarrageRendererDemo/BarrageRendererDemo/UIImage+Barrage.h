//
//  UIImage+Barrage.h
//
//  Created by UnAsh on 15/7/8.
//  Copyright (c) 2015年 UnAsh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Barrage)
- (UIImage *)barrageImageScaleToSize:(CGSize)size;
@end
