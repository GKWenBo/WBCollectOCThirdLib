//
//  AvatarBarrageView.h
//  BarrageRendererDemo
//
//  Created by InAsh on 20/07/2017.
//  Copyright © 2017 ExBye Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BarrageRenderer/BarrageSpriteProtocol.h>

@interface AvatarBarrageView : UIView<BarrageViewProtocol>

@end
