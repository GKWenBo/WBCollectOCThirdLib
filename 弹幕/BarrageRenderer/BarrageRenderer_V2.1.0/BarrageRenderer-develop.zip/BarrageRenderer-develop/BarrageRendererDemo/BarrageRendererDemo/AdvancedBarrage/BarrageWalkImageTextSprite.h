//
//  BarrageWalkImageTextSprite.h
//  BarrageRendererDemo
//
//  Created by UnAsh on 15/11/15.
//  Copyright (c) 2015年 ExBye Inc. All rights reserved.
//

#import <BarrageRenderer/BarrageWalkTextSprite.h>

@interface BarrageWalkImageTextSprite : BarrageWalkTextSprite

@end
