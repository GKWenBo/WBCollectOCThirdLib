//
//  MLEmojiLabel+BarrageView.h
//  BarrageRendererDemo
//
//  Created by UnAsh on 16/12/12.
//  Copyright © 2016年 ExBye Inc. All rights reserved.
//

#import <MLEmojiLabel/MLEmojiLabel.h>

@interface MLEmojiLabel (BarrageView)

@end
