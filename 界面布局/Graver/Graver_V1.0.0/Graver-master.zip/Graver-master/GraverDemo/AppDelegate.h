//
//  AppDelegate.h
//  GraverDemo
//
//  Created by yangyang on 2018/11/29.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

