//
//  DemoOrderListViewModel.h
//  GraverDemo
//
//  Created by jiangwei on 2018/12/5.
//

#import "WMGBaseViewModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface DemoOrderListViewModel : WMGBaseViewModel

@end

NS_ASSUME_NONNULL_END
