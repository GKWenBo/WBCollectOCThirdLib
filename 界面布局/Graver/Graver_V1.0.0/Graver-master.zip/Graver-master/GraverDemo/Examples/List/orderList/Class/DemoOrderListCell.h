//
//  DemoOrderListCell.h
//  WMCoreText
//
//  Created by jiangwei on 2018/11/28.
//  Copyright © 2018 sankuai. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WMGBaseCell.h"

NS_ASSUME_NONNULL_BEGIN

@interface DemoOrderListCell : WMGBaseCell


@end

NS_ASSUME_NONNULL_END
