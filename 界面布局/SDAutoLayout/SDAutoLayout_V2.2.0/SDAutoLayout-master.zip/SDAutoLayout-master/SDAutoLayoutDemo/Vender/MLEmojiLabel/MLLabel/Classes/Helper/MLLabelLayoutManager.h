//
//  MLLabelLayoutManager.h
//  MLLabel
//
//  Created by molon on 15/6/11.
//  Copyright (c) 2015年 molon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MLLabelLayoutManager : NSLayoutManager

@end
