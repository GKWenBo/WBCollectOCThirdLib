//
//  SDRefreshFooterView.h
//  SDRefreshView
//
//  Created by aier on 15-2-23.
//  Copyright (c) 2015年 GSD. All rights reserved.
//

#import "SDRefreshView.h"

@interface SDRefreshFooterView : SDRefreshView

@end
