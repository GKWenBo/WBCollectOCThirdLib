//
//  AllTest9CollectionViewCell.h
//  MyLayoutDemo
//
//  Created by oubaiquan on 2017/11/1.
//  Copyright © 2017年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AllTestDataModel.h"


@interface AllTest9CollectionViewCell : UICollectionViewCell

@property(nonatomic, strong) AllTest9DataModel *model;

@end
