//
//  LLTest4ViewController.h
//  MyLayout
//
//  Created by oybq on 15/6/21.
//  Copyright (c) 2015年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *4.LinearLayout - Wrap content
 */
@interface LLTest4ViewController : UIViewController

@end
