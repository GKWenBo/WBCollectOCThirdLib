//
//  PLTest4ViewController.h
//  MyLayout
//
//  Created by apple on 16/7/31.
//  Copyright © 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *4.PathLayout - Fan
 */
@interface PLTest5ViewController : UIViewController

@end
