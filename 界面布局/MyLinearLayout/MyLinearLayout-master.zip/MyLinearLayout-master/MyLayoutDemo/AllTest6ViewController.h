//
//  AllTest6ViewController.h
//  MyLayout
//
//  Created by oybq on 16/2/5.
//  Copyright (c) 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *2.SizeClass - Demo2
 */
@interface AllTest6ViewController : UIViewController

@end
