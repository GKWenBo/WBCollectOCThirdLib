//
//  AllTest4ViewController.h
//  MyLayout
//
//  Created by oybq on 15/7/6.
//  Copyright (c) 2015年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  4.Replacement of UICollectionView
 */
@interface AllTest4ViewController : UIViewController

@end
