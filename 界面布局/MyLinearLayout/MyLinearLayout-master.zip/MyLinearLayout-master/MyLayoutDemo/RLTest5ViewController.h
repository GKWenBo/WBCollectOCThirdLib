//
//  RLTest5ViewController.h
//  MyLayout
//
//  Created by oybq on 16/12/19.
//  Copyright (c) 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * 5.RelativeLayout - Boundary limit
 */
@interface RLTest5ViewController : UIViewController

@end
