//
//  FOLTest5ViewController.h
//  MyLayout
//
//  Created by oybq on 16/2/19.
//  Copyright © 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *5.FloatLayout - Title & Description
 */
@interface FOLTest5ViewController : UIViewController

@end
