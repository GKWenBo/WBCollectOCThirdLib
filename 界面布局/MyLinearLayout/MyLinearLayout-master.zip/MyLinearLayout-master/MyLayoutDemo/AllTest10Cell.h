//
//  AllTest10Cell.h
//  FriendListDemo
//
//  Created by bsj_mac_2 on 2018/5/7.
//  Copyright © 2018年 bsj_mac_2. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyLayout.h"

@interface AllTest10Cell : UITableViewCell

- (void)setCommentsText:(NSString *)text;
@end
