//
//  CFTool.h
//  MyLayout
//
//  Created by apple on 16/11/17.
//  Copyright © 2016年 YoungSoft. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

//字体颜色工具
@interface CFTool : NSObject

+(UIColor*)color:(NSInteger)idx;

+(UIFont*)font:(CGFloat)size;



@end
