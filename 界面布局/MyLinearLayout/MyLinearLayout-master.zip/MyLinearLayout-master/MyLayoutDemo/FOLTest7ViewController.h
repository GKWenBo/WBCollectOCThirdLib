//
//  FOLTest7ViewController.h
//  MyLayout
//
//  Created by oybq on 16/2/19.
//  Copyright © 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *7.FloatLayout - Alignment
 */
@interface FOLTest7ViewController : UIViewController

@end
