//
//  AllTest3ViewController.h
//  MyLayout
//
//  Created by oybq on 15/6/24.
//  Copyright (c) 2015年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *3.Replacement of UITableView
 */
@interface AllTest3ViewController : UIViewController

@end
