//
//  LLTest5ViewController.h
//  MyLayout
//
//  Created by oybq on 15/6/21.
//  Copyright (c) 2015年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *5.LinearLayout - Weight & Relative margin
 */
@interface LLTest5ViewController : UIViewController

@end
