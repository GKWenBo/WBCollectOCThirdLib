//
//  AllTest5ViewController.h
//  MyLayout
//
//  Created by fzy on 16/1/24.
//  Copyright © 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *1.SizeClass - Demo1
 */
@interface AllTest5ViewController : UIViewController

@end
