//
//  RLTest2ViewController.h
//  MyLayout
//
//  Created by oybq on 15/7/6.
//  Copyright (c) 2015年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * 2.RelativeLayout - Prorate size
 */
@interface RLTest2ViewController : UIViewController

@end
