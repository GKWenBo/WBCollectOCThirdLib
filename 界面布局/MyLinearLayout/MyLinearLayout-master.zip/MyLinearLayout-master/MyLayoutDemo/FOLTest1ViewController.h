//
//  FOLTest1ViewController.h
//  MyLayout
//
//  Created by oybq on 16/2/19.
//  Copyright © 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * 1.FloatLayout - Float
 */
@interface FOLTest1ViewController : UIViewController

@end
