//
//  PLTest2ViewController.h
//  MyLayout
//
//  Created by apple on 16/7/26.
//  Copyright © 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *2.PathLayout - Curves
 */
@interface PLTest2ViewController : UIViewController

@end
