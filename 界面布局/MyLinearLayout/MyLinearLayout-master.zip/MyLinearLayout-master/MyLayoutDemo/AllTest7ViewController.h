//
//  AllTest7ViewController.h
//  MyLayout
//
//  Created by apple on 16/10/21.
//  Copyright © 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *❁1.Screen perfect fit - Demo1
 */
@interface AllTest7ViewController : UIViewController

@end
