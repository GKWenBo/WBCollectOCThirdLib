//
//  LLTest2ViewController.h
//  MyLayout
//
//  Created by oybq on 15/6/21.
//  Copyright (c) 2015年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *2.LinearLayout - Combine with UIScrollView
 */
@interface LLTest2ViewController : UIViewController

@end
