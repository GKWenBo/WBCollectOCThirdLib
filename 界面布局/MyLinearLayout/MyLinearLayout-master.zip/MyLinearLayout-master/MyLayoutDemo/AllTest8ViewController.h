//
//  AllTest8ViewController.h
//  MyLayout
//
//  Created by apple on 16/12/22.
//  Copyright © 2016年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * ❁2.Screen perfect fit - Demo2
 */
@interface AllTest8ViewController : UIViewController

@end
