//
//  AllTestDataModel.m
//  MyLayout
//
//  Created by apple on 16/5/25.
//  Copyright © 2016年 YoungSoft. All rights reserved.
//

#import "AllTestDataModel.h"

@implementation AllTest1DataModel


@end

@implementation AllTest2DataModel


@end


@implementation AllTest9DataModel


@end
