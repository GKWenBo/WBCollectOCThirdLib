//
//  RLTest3ViewController.h
//  MyLayout
//
//  Created by oybq on 15/7/9.
//  Copyright (c) 2015年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 * 3.RelativeLayout - Centered
 */
@interface RLTest3ViewController : UIViewController

@end
