//
//  TLT3ViewController.h
//  MyLayout
//
//  Created by oybq on 15/7/18.
//  Copyright (c) 2015年 YoungSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *3.TableLayout - Intelligent Borderline
 */
@interface TLTest3ViewController : UIViewController

@end
