//
//  WHC_ProcessBar.h
//  WHC_AutoLayoutExample
//
//  Created by 吴海超 on 16/3/22.
//  Copyright © 2016年 吴海超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WHC_ProcessBar : UIView

@end
