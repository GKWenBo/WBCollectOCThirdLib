//
//  MASExampleArrayView.h
//  Masonry iOS Examples
//
//  Created by Daniel Hammond on 11/26/13.
//  Copyright (c) 2013 Jonas Budelmann. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MASExampleArrayView : UIView

@end
