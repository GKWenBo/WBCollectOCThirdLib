//
//  MJBox.m
//  MJExtensionExample
//
//  Created by MJ Lee on 15/6/10.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "MJBox.h"
#import "MJExtension.h"

@implementation MJBox
MJExtensionCodingImplementation
@end
