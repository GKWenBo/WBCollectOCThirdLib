//
//  MJBox.h
//  MJExtensionExample
//
//  Created by MJ Lee on 15/6/10.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MJBox : NSObject
@property (assign, nonatomic) double weight;
@property (assign, nonatomic) int size;
@end
