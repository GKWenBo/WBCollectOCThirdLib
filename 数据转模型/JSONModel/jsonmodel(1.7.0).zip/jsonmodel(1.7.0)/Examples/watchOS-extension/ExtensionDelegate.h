//
//  ExtensionDelegate.h
//  watchOS-extension
//
//  Created by James Billingham on 23/06/2016.
//  Copyright © 2012-2016, JSONModel contributors. MIT licensed.
//

@import WatchKit;

@interface ExtensionDelegate : NSObject <WKExtensionDelegate>

@end
