//
//  GitHubKeyMapRepoModelDict.h
//  JSONModelDemo
//
//  Created by Marin Todorov on 20/12/2012.
//  Copyright (c) 2012 Underplot ltd. All rights reserved.
//

#import "GitHubKeyMapRepoModel.h"

@interface GitHubKeyMapRepoModelDict : GitHubKeyMapRepoModel

@end
