//
//  JSONTypesModelWithValidation2.h
//  JSONModelDemo
//
//  Created by Marin Todorov on 17/12/2012.
//  Copyright (c) 2012 Underplot ltd. All rights reserved.
//

#import "JSONTypesModel.h"

@interface JSONTypesModelWithValidation2 : JSONTypesModel

@end
