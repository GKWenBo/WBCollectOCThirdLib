//
//  SpecialPropertyModel.h
//  JSONModelDemo_OSX
//
//  Created by BB9z on 13-4-26.
//  Copyright (c) 2013年 Underplot ltd. All rights reserved.
//

@import JSONModel;

@interface SpecialPropertyModel : JSONModel

@property (strong, nonatomic) NSString *className;
@property (strong, nonatomic) NSString *indexPropertyName;
@property (strong, nonatomic) NSString *id;

@end
