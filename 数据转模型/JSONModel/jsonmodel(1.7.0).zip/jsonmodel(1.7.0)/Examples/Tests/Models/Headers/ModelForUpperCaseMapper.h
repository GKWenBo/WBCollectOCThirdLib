//
// Created by Petr Korolev on 21/02/14.
// Copyright (c) 2014 Underplot ltd. All rights reserved.
//

@import JSONModel;

@interface ModelForUpperCaseMapper : JSONModel

@property (strong, nonatomic) NSString* uppertest;

@end
