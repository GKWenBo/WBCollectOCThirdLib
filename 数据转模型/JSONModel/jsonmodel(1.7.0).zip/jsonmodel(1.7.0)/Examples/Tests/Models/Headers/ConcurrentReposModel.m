//
//  ConcurrentModel.m
//  Examples
//
//  Created by robin on 9/8/16.
//  Copyright © 2016 JSONModel. All rights reserved.
//

#import "ConcurrentReposModel.h"

@implementation ConcurrentModel

@end

@implementation ConcurrentReposModel

@end
