//
//  PrimitivesModel.m
//  JSONModelDemo
//
//  Created by Marin Todorov on 02/12/2012.
//  Copyright (c) 2012 Underplot ltd. All rights reserved.
//

#import "PrimitivesModel.h"

@implementation PrimitivesModel
@end
