//
//  SpecialPropertyModel.m
//  JSONModelDemo_OSX
//
//  Created by BB9z on 13-4-26.
//  Copyright (c) 2013年 Underplot ltd. All rights reserved.
//

#import "SpecialPropertyModel.h"

@implementation SpecialPropertyModel
@end
