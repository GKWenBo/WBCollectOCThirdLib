//
//  AppDelegate.h
//  iOS
//
//  Created by James Billingham on 23/06/2016.
//  Copyright © 2012-2016, JSONModel contributors. MIT licensed.
//

@import UIKit;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
