//
//  main.m
//  iOS
//
//  Created by James Billingham on 23/06/2016.
//  Copyright © 2012-2016, JSONModel contributors. MIT licensed.
//

@import UIKit;

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
	@autoreleasepool
	{
		return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
	}
}
