//
//  TTAVPlayerTimeLabel.h
//  Multimedia
//
//  Created by dylan.tang on 17/2/6.
//  Copyright © 2017年 dylan.tang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTAVPlayerTimeLabel : UILabel

- (void)setTime:(CGFloat)currentTime;

@end
