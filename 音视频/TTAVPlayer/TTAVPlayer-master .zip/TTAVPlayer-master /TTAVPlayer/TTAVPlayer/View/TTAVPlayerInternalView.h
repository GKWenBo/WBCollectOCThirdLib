//
//  TTAVPlayerInternalView.h
//  Multimedia
//
//  Created by dylan.tang on 17/2/5.
//  Copyright © 2017年 dylan.tang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTAVPlayerInternalView : UIView

@end
