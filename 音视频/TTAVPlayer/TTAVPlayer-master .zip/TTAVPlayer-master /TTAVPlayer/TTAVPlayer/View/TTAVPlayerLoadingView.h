//
//  TTAVPlayerLoadingView.h
//  Multimedia
//
//  Created by dylan.tang on 17/2/20.
//  Copyright © 2017年 dylan.tang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTAVPlayerLoadingView : UIView

@end
