//
//  TTAVPlayer.h
//  TTAVPlayer
//
//  Created by dylan.tang on 17/3/23.
//  Copyright © 2017年 dylan.tang. All rights reserved.
//

#ifndef TTAVPlayer_h
#define TTAVPlayer_h

#import "TTAVPlayerView.h"
#import "TTAVPlayerVideoInfo.h"

#endif /* TTAVPlayer_h */
