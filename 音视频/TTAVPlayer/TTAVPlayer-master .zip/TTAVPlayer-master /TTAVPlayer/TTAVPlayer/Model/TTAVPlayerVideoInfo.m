//
//  TTAVPlayerVideoInfo.m
//  Multimedia
//
//  Created by dylan.tang on 17/2/7.
//  Copyright © 2017年 dylan.tang. All rights reserved.
//

#import "TTAVPlayerVideoInfo.h"

@implementation TTAVPlayerVideoInfo

@end
