//
//  ViewController.h
//  tripavplayer
//
//  Created by dylan.tang on 17/3/23.
//  Copyright © 2017年 dylan.tang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

