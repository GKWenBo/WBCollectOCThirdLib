//
//  AppDelegate.h
//  TBPlayer
//
//  Created by qianjn on 2016/11/16.
//  Copyright © 2016年 SF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

