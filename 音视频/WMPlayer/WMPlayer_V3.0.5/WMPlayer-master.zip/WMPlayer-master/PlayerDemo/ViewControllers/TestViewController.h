//
//  TestViewController.h
//  WMPlayer
//
//  Created by zhengwenming on 16/6/10.
//  Copyright © 2016年 郑文明. All rights reserved.
//

#import "BaseViewController.h"

@interface TestViewController : BaseViewController

@end
