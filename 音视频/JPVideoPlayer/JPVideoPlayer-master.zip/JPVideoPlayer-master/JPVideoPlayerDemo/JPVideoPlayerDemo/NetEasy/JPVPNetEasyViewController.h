//
//  JPVideoPlayerNetEasyViewController.h
//  JPVideoPlayerDemo
//
//  Created by Memet on 2018/4/24.
//  Copyright © 2018 NewPan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JPVPNetEasyViewController : UITableViewController

@end
