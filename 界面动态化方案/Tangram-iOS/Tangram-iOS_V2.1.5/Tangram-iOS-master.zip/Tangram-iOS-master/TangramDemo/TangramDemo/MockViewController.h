//
//  MockViewController.h
//  TangramDemo
//
//  Copyright (c) 2017-2018 Alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MockViewController : UIViewController

@end
