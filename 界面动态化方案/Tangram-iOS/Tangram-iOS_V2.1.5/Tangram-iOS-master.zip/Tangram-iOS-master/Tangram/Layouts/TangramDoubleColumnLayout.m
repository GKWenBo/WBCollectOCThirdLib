//
//  TangramDoubleColumnLayout.m
//  Tangram
//
//  Copyright (c) 2017-2018 Alibaba. All rights reserved.
//

#import "TangramDoubleColumnLayout.h"

@implementation TangramDoubleColumnLayout

-(NSUInteger)numberOfColumns
{
    return 2;
}
-(void)calculateLayout
{
    [super calculateLayout];
}
@end
