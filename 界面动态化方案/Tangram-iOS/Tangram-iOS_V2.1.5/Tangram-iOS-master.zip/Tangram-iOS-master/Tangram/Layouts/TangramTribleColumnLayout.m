//
//  TangramTribleColumnLayout.m
//  Tangram
//
//  Copyright (c) 2017-2018 Alibaba. All rights reserved.
//

#import "TangramTribleColumnLayout.h"

@implementation TangramTribleColumnLayout

-(NSUInteger)numberOfColumns
{
    return 3;
}

@end
