//
//  TangramDragableLayout.h
//  Tangram
//
//  Copyright (c) 2017-2018 Alibaba. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TangramLayoutProtocol.h"
#import "TangramFixLayout.h"

@interface TangramDragableLayout : TangramFixLayout


@end
