//
//  TangramStickyBottomLayout.m
//  Tangram
//
//  Copyright (c) 2017-2018 Alibaba. All rights reserved.
//

#import "TangramStickyBottomLayout.h"

@implementation TangramStickyBottomLayout

-(BOOL)stickyBottom
{
    return YES;
}

@end
