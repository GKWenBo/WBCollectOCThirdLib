//
//  TangramSingleColumnLayout.m
//  Tangram
//
//  Copyright (c) 2017-2018 Alibaba. All rights reserved.
//

#import "TangramSingleColumnLayout.h"

@implementation TangramSingleColumnLayout

-(NSUInteger)numberOfColumns
{
    return 1;
}

@end
