//
//  TangramTetradColumnLayout.m
//  Tangram
//
//  Copyright (c) 2017-2018 Alibaba. All rights reserved.
//

#import "TangramTetradColumnLayout.h"

@implementation TangramTetradColumnLayout

-(NSUInteger)numberOfColumns
{
    return 4;
}
@end
