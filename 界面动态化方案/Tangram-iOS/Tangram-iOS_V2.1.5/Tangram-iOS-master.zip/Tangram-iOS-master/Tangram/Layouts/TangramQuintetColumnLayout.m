//
//  TangramQuintetColumnLayout.m
//  Tangram
//
//  Copyright (c) 2017-2018 Alibaba. All rights reserved.
//

#import "TangramQuintetColumnLayout.h"

@implementation TangramQuintetColumnLayout

-(NSUInteger)numberOfColumns
{
    return 5;
}

@end
