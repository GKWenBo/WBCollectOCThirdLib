#! /bin/sh

addr2line -e ijkplayer/ijkplayer-armv7a/src/main/obj/local/armeabi-v7a/lib$1.so
