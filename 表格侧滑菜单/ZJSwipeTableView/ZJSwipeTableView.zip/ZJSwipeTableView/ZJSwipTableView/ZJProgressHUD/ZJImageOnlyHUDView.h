//
//  ZJImageOnlyHUDView.h
//  ZJProgressHUD
//
//  Created by ZeroJ on 16/9/7.
//  Copyright © 2016年 ZeroJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZJImageOnlyHUDView : UIView
/** 设置图片 */
@property (strong, nonatomic) UIImage *image;
@end
