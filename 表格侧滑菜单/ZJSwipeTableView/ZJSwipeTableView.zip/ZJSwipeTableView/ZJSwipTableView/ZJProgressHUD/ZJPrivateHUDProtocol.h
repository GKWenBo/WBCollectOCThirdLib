//
//  ZJPrivateHUDProtocol.h
//  ZJProgressHUD
//
//  Created by ZeroJ on 16/9/8.
//  Copyright © 2016年 ZeroJ. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ZJPrivateHUDProtocol <NSObject>

@end
