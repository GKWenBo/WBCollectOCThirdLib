

#import <UIKit/UIKit.h>
#import "KafkaAppDelegate.h"

int main(int argc, char * argv[]) {
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([KafkaAppDelegate class]));
	}
}
