//
//  Demo6SubViewController.h
//  微博照片选择
//
//  Created by 洪欣 on 2017/7/26.
//  Copyright © 2017年 洪欣. All rights reserved.
//

#import <UIKit/UIKit.h>
@class HXPhotoManager;
@interface Demo6SubViewController : UIViewController
@property (strong, nonatomic) HXPhotoManager *manager;
@end
