//
//  CollectionViewEmbedTableViewController.h
//  WZLBadgeDemo
//
//  Created by felix on 2017/6/19.
//  Copyright © 2017年 Weng-Zilin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewCollectionViewController : UIViewController

@end
