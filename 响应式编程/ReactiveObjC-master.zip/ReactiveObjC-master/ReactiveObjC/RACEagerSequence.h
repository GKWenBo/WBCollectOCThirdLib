//
//  RACEagerSequence.h
//  ReactiveObjC
//
//  Created by Uri Baghin on 02/01/2013.
//  Copyright (c) 2013 GitHub, Inc. All rights reserved.
//

#import "RACArraySequence.h"

// Private class that implements an eager sequence.
@interface RACEagerSequence : RACArraySequence

@end
