This folder contains conceptual documentation and design guidelines that don't
fit well on a single class or in any specific header file.
