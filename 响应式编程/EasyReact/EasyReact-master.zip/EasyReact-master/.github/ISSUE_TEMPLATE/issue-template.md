---
name: Issue template
about: Describe this issue template's purpose here.

---

<!--
Thanks for using EasyReact!
-->

### Context and Description

<!-- A description of the issue. -->

### Environment Details

* EasyReact version:
* iOS version:
* Xcode version:
* Other informations:

### Expected behavior

<!-- What do you think should happen? -->

### Actual behavior

<!-- What actually happens? -->

### Steps to Reproduce
