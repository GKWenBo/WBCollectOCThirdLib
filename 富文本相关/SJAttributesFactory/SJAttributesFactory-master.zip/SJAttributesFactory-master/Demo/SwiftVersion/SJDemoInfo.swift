//
//  SJDemoInfo.swift
//  SwiftVersion
//
//  Created by BlueDancer on 2018/1/28.
//  Copyright © 2018年 畅三江. All rights reserved.
//

import UIKit

class SJDemoInfo: NSObject {
    var name: String?
    var task: (() -> NSAttributedString)?
    var size: CGSize?
}
