//
//  KMButton.h
//  Movies
//
//  Created by Kevin Mindeguia on 09/03/2016.
//  Copyright © 2016 iKode Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface KMButton : UIButton

@end
