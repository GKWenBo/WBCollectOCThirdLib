//
//  ViewController.h
//  DDGBannerScrollViewDemo
//
//  Created by dudongge on 2019/1/7.
//  Copyright © 2019 dudongge. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

