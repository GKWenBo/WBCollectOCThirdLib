//
//  AppDelegate.h
//  TXScrollLabelViewDemo
//
//  Created by tingxins on 20/10/2016.
//  Copyright © 2016 tingxins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

