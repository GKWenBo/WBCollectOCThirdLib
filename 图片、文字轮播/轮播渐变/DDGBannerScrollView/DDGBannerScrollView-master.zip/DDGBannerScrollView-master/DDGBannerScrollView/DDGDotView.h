//
//  TADotView.h
//  TAPageControl
//
//  Created by dudongge on 2018/12/26.
//  Copyright © 2018 dudongge. All rights reserved.
//

#import "DDGAbstractDotView.h"

@interface DDGDotView : DDGAbstractDotView

@end
