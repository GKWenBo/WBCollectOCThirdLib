//
//  TYCyclePagerViewDemo_swift-Brdging-Header.h
//  TYCyclePagerViewDemo_swift
//
//  Created by tany on 2017/7/20.
//  Copyright © 2017年 tany. All rights reserved.
//

#ifndef TYCyclePagerViewDemo_swift_Brdging_Header_h
#define TYCyclePagerViewDemo_swift_Brdging_Header_h

#import "TYCyclePagerView.h"
#import "TYPageControl.h"

#endif /* TYCyclePagerViewDemo_swift_Brdging_Header_h */
