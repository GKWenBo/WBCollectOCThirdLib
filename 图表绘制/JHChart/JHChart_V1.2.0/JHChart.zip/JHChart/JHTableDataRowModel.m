//
//  JHTableDataRowModel.m
//  JHChartDemo
//
//  Created by 简豪 on 16/8/25.
//  Copyright © 2016年 JH. All rights reserved.
//

#import "JHTableDataRowModel.h"

@implementation JHTableDataRowModel

@end
