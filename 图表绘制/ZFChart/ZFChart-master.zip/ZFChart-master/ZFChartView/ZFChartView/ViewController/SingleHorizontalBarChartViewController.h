//
//  SingleHorizontalBarChartViewController.h
//  ZFChartView
//
//  Created by apple on 16/5/30.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SingleHorizontalBarChartViewController : UIViewController

@end
