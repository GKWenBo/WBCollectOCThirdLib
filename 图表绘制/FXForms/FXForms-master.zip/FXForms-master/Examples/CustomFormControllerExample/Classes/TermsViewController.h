//
//  TermsViewController.h
//  BasicExample
//
//  Created by Nick Lockwood on 08/03/2014.
//  Copyright (c) 2014 Charcoal Design. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TermsViewController : UIViewController

@end
