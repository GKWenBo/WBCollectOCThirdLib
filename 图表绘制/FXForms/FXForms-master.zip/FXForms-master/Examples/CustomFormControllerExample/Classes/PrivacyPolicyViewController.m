//
//  PrivacyPolicyViewController.m
//  BasicExample
//
//  Created by Nick Lockwood on 08/03/2014.
//  Copyright (c) 2014 Charcoal Design. All rights reserved.
//

#import "PrivacyPolicyViewController.h"

@implementation PrivacyPolicyViewController

//nothing to see here

@end
