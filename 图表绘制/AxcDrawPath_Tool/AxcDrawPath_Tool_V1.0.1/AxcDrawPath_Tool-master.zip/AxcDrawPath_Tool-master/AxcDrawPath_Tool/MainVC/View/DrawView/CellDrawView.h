//
//  CellDrawView.h
//  AxcDrawPath_Tool
//
//  Created by AxcLogo on 2018/10/26.
//  Copyright © 2018 AxcLogo. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CellDrawView : UIView

@property(nonatomic , strong)CAShapeLayer *showLayer;


@end

NS_ASSUME_NONNULL_END
