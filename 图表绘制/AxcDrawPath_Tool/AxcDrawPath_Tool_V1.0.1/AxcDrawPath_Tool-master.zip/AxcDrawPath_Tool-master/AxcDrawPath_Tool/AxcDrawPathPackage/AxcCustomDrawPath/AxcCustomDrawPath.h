//
//  AxcCustomDrawPath.h
//  AxcDrawPath_Tool
//
//  Created by AxcLogo on 2018/10/29.
//  Copyright © 2018 AxcLogo. All rights reserved.
//

#import "AxcDrawPath.h"

NS_ASSUME_NONNULL_BEGIN

/** 自定义图案API对象 */
@interface AxcCustomDrawPath : AxcDrawPath

@end

NS_ASSUME_NONNULL_END
