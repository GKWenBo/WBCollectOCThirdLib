//
//  UITextField+Test.h
//  XLForm Tests
//
//  Created by Gaston Borba on 3/25/15.
//
//

#import <UIKit/UIKit.h>

@interface UITextField (Test)

// This category is for simulate the change of the text
-(void)changeText:(NSString *)string;

@end
