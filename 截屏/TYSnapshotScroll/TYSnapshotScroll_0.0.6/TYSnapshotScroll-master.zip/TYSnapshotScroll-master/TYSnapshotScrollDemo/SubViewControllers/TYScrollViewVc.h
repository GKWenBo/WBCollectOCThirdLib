//
//  TYScrollViewVc.h
//  TYSnapshotScroll
//
//  Created by TonyReet on 2017/11/22.
//  Copyright © 2017年 TonyReet. All rights reserved.
//

#import "TYBaseVc.h"

@interface TYScrollViewVc : TYBaseVc

@end
