//
//  TYWKWebViewVc.h
//  TYSnapshotScroll
//
//  Created by apple on 16/12/27.
//  Copyright © 2016年 TonyReet. All rights reserved.
//

#import "TYBaseVc.h"

@interface TYWKWebViewVc : TYBaseVc

@end
