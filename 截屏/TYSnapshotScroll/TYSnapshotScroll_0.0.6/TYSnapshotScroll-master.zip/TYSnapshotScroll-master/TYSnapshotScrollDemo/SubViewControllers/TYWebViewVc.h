//
//  TYWebViewVc.h
//  TYSnapshotScroll
//
//  Created by apple on 16/12/26.
//  Copyright © 2016年 TonyReet. All rights reserved.
//

#import "TYBaseVc.h"

@interface TYWebViewVc : TYBaseVc

@end
