//
//  TYCollectionViewVc.h
//  TYSnapshotScroll
//
//  Created by TonyReet on 2017/12/24.
//  Copyright © 2017年 TonyReet. All rights reserved.
//

#import "TYBaseVc.h"

@interface TYCollectionViewVc : TYBaseVc

@end
