//
//  UIViewController+TYSnapshot.h
//  TYSnapshotScroll
//
//  Created by tonyreet on 2018/9/20.
//  Copyright © 2018年 TonyReet. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (TYSnapshot)

+ (UIViewController *)currentViewController;

@end
