# Version 1.1.0

 + Added `CECardsAnimationController`
 + Added `CEVerticalSwipeInteractionController`
 + Renamed `CESwipeInteractionController` to `CEHorizontalInteractionController`

# Version 1.0.0

Initial release.