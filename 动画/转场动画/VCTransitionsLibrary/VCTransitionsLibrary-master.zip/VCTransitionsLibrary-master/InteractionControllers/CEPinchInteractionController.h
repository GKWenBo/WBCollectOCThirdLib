//
//  CEPinchInteractionController.h
//  TransitionsDemo
//
//  Created by Colin Eberhardt on 16/09/2013.
//  Copyright (c) 2013 Colin Eberhardt. All rights reserved.
//

#import "CEBaseInteractionController.h"

@interface CEPinchInteractionController : CEBaseInteractionController

@end
