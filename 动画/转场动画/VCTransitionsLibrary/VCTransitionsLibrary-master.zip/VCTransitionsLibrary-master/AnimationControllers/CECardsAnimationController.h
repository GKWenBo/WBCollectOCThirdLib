//
//  CEZoomAnimationController.h
//  TransitionsDemo
//
//  Created by Colin Eberhardt on 22/09/2013.
//  Copyright (c) 2013 Colin Eberhardt. All rights reserved.
//

#import "CEReversibleAnimationController.h"

@interface CECardsAnimationController : CEReversibleAnimationController

@end
